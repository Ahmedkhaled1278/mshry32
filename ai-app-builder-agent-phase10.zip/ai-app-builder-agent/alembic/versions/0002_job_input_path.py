"""Persist uploaded source ZIP paths for repair jobs.

Revision ID: 0002_job_input_path
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_job_input_path"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("jobs", sa.Column("input_path", sa.Text(), nullable=True), schema="app")


def downgrade() -> None:
    op.drop_column("jobs", "input_path", schema="app")
