"""Initial app schema.

Revision ID: 0001_initial
Revises:
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE SCHEMA IF NOT EXISTS app")
    op.create_table("users",
        sa.Column("id", sa.BigInteger(), primary_key=True),
        sa.Column("username", sa.Text()), sa.Column("first_name", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("jobs_today", sa.Integer(), server_default="0", nullable=False),
        sa.Column("last_reset", sa.Date(), server_default=sa.text("CURRENT_DATE"), nullable=False),
        schema="app")
    op.create_table("projects",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", sa.BigInteger(), sa.ForeignKey("app.users.id"), nullable=False),
        sa.Column("name", sa.Text(), nullable=False), sa.Column("description", sa.Text(), nullable=False),
        sa.Column("project_type", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("project_type IN ('web', 'android')", name="ck_projects_type"), schema="app")
    op.create_table("jobs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("app.projects.id"), nullable=False),
        sa.Column("status", sa.Text(), nullable=False), sa.Column("current_node", sa.Text()),
        sa.Column("error", sa.Text()), sa.Column("token_usage", sa.Integer(), server_default="0", nullable=False),
        sa.Column("iterations", sa.Integer(), server_default="0", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True)), schema="app")
    op.create_table("events",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column("job_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("app.jobs.id"), nullable=False),
        sa.Column("ts", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("node", sa.Text()), sa.Column("event_type", sa.Text()),
        sa.Column("payload", postgresql.JSONB()), schema="app")
    op.create_table("artifacts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("job_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("app.jobs.id"), nullable=False),
        sa.Column("kind", sa.Text(), nullable=False), sa.Column("s3_key", sa.Text(), nullable=False),
        sa.Column("size_bytes", sa.BigInteger()), sa.Column("sha256", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False), schema="app")
    op.create_index("idx_jobs_status", "jobs", ["status"], schema="app")
    op.create_index("idx_jobs_project", "jobs", ["project_id"], schema="app")
    op.create_index("idx_events_job_ts", "events", ["job_id", "ts"], schema="app")


def downgrade() -> None:
    op.drop_index("idx_events_job_ts", table_name="events", schema="app")
    op.drop_index("idx_jobs_project", table_name="jobs", schema="app")
    op.drop_index("idx_jobs_status", table_name="jobs", schema="app")
    for table in ("artifacts", "events", "jobs", "projects", "users"):
        op.drop_table(table, schema="app")
