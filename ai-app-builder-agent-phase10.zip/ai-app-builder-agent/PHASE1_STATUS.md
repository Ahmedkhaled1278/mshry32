# Phase 1 status — implementation revision

Status: **implementation advanced; end-to-end acceptance is not yet verified**.

## Implemented in source

- Telegram command handlers (`/start`, `/help`, `/new`, `/repair`, `/status`, `/cancel`) and authenticated webhook endpoint.
- Limited safe repair flow for ZIPs containing the three supported web files; source ZIP is never extracted, and paths/symlinks/size limits are checked.
- Migration `0002_job_input_path` to persist repair upload locations across worker execution.
- Production configuration validation rejects blank API credentials, the example webhook secret, and several development defaults.
- SQLAlchemy models and Alembic initial schema for users/projects/jobs/events/artifacts.
- Redis/RQ worker entrypoint.
- LangGraph workflow nodes and conditional build/test/fix/security/verifier/delivery routing.
- OpenAI JSON generation with strict generated-file allowlist and per-file limits.
- Trusted dependency-free `package.json`, build script, and Node test script.
- Docker sandbox runner with network disabled, resource limits, read-only root, no capabilities, non-root execution, and timeout cleanup.
- Static security review, bounded repair loop, token accounting, ZIP integrity + SHA-256, MinIO/S3 upload and download-back verification, Telegram delivery gate.
- Postgres checkpointer and persistent job workspace paths intended to support checkpoint-based continuation; hard-crash recovery has not been proven end-to-end.
- Optional bolt.diy developer UI profile; no undocumented headless API is assumed.

## Checks actually run in this build environment

- `python -m compileall -q src tests`: passed.
- Generated-project smoke fixture: offline npm install, build, and 2/2 Node tests passed.
- Docker Compose YAML parsed successfully with required services.
- Python unit tests after ZIP repair, symlink, configuration, HTML asset, and static security checks: **38 passed, 2 skipped**.
- Docker Compose YAML parsed with PyYAML and expected services/volumes were present.
- Deterministic generated-project harness executed on the host as a fixture: `npm install --offline`, `npm run build`, and `npm test` all passed; Node reported 2/2 tests passed.

## Not verified here

- Docker is unavailable in the build environment, so no Docker image build, Docker sandbox execution, or `docker compose up` test was performed.
- OpenAI API call, live Telegram webhook/bot delivery, PostgreSQL checkpoint recovery, Redis/RQ integration, MinIO upload/download, and the full CI suite were not run end-to-end.
- The fixture run on the host validates the controlled build harness only; it is not proof that the Docker sandbox or a model-generated application passed.
- Limited repair unit tests validate archive parsing and safety boundaries, not a live OpenAI-assisted repair/delivery cycle.
- Worker kill/restart resumption requires a dedicated integration test before G4 is marked complete.

See `PHASE1_ACCEPTANCE.md` for the current acceptance matrix and remaining integration gates.

## Known Phase 1 limitation

The generator is constrained to dependency-free browser JavaScript. This makes offline install and network-disabled builds compatible; adding arbitrary npm dependencies needs a separately reviewed allowlisted dependency-fetch design and is not enabled by this revision.
