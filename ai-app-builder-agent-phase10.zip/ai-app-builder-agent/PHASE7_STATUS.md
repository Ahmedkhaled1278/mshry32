# Phase 7 — Multi-file patch-plan core

## Implemented
- Added a conservative declarative patch-plan validator for create/update/delete operations.
- Requires update/delete preconditions to match the original source snapshot before any operation begins.
- Rejects duplicate target paths, unknown actions, missing targets, malformed content, oversized plans, and excessive operation counts.
- Delegates path and file-type enforcement to the existing `patch_engine` and adds tests including a real temporary-workspace update.

## Explicit limits
- This is not yet wired to Telegram or the job pipeline.
- It does not ask OpenAI to produce a patch plan.
- It does not run project-specific tests/builds or create an APK.
- Prevalidation reduces avoidable partial changes, but the underlying multi-operation patch engine is not a full filesystem transaction; use a disposable workspace and snapshot/rollback in the next integration step.
