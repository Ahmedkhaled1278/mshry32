# Phase 4 — Safe multi-file patch core

## Added
- `src/agent/patch_engine.py`: validates a bounded JSON patch plan (`create`, `update`, `delete`) and applies it only under an explicit workspace.
- Rejects traversal/absolute paths, symlinks, duplicate paths, dependency/build folders, unsupported file types, oversized files, and invalid operation preconditions.
- Validates every operation and target precondition before applying any mutation; writes replacements atomically.
- `tests/test_patch_engine.py`: tests normal changes, precondition atomicity, traversal, forbidden paths, duplicate operations, size limits, and symlink targets.

## Important scope boundary
This is a reusable, tested patch-application core. Phase 4 does **not** yet route arbitrary project ZIP uploads through a multi-framework AI repair pipeline. The current Telegram `/repair` path still accepts the bounded three-file HTML/CSS/JS prototype only. Do not claim arbitrary-project repair or APK build support until those paths are integrated and tested in a Docker-enabled deployment.

## Verification
Run from this folder:

```bash
python -m pytest -q
```

Docker-backed build/test and live Telegram/OpenAI integration still require configured external services and must be tested in deployment.
