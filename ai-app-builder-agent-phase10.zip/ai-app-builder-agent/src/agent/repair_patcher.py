"""Apply AI-generated web repair outputs through the bounded patch engine."""
from __future__ import annotations

from pathlib import Path

from src.agent.openai_generator import ALLOWED_GENERATED_FILES, _validate_files
from src.agent.patch_engine import apply_patch_plan


def apply_web_repair(workspace: str | Path, generated_files: dict[str, str]):
    """Update only the three supported prototype files via validated patch operations."""
    root = Path(workspace).resolve(strict=True)
    files = _validate_files(generated_files)
    plan = []
    for name in sorted(ALLOWED_GENERATED_FILES):
        target = root / name
        if target.is_symlink() or not target.is_file():
            raise ValueError(f"ملف الإصلاح الأصلي غير موجود أو غير آمن: {name}")
        plan.append({"op": "update", "path": name, "content": files[name]})
    return apply_patch_plan(root, plan)
