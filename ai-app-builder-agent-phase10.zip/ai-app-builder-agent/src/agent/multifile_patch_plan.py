"""Conservative multi-file patch-plan validation and application.

This module deliberately accepts a small declarative patch format and delegates
path/operation enforcement to the existing patch engine. It does not call an LLM,
run project code, or claim framework build support.
"""
from __future__ import annotations

from typing import Any
from src.agent.patch_engine import apply_patch_plan

MAX_PLAN_OPERATIONS = 100
MAX_PLAN_BYTES = 256 * 1024
ALLOWED_ACTIONS = {"create", "update", "delete"}

def validate_patch_plan(plan: Any, source_files: dict[str, str]) -> list[dict[str, str]]:
    """Validate shape and preconditions before any mutation."""
    if not isinstance(plan, list):
        raise ValueError("Patch plan must be a list.")
    if not plan or len(plan) > MAX_PLAN_OPERATIONS:
        raise ValueError("Patch plan must contain between 1 and 100 operations.")
    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    total = 0
    for index, item in enumerate(plan):
        if not isinstance(item, dict):
            raise ValueError(f"Operation {index} must be an object.")
        action = item.get("action")
        path = item.get("path")
        if action not in ALLOWED_ACTIONS:
            raise ValueError(f"Operation {index} has an unsupported action.")
        expected_keys = {
            "create": {"action", "path", "content"},
            "update": {"action", "path", "old_content", "new_content"},
            "delete": {"action", "path", "old_content"},
        }[action]
        if set(item) != expected_keys:
            raise ValueError(f"Operation {index} has missing or unexpected fields.")
        if not isinstance(path, str) or not path.strip() or path != path.strip():
            raise ValueError(f"Operation {index} has no valid path.")
        if path in seen:
            raise ValueError(f"Duplicate patch path: {path}")
        seen.add(path)
        op: dict[str, str] = {"op": action, "path": path}
        if action == "create":
            if path in source_files:
                raise ValueError(f"Create target already exists: {path}")
            content = item.get("content")
            if not isinstance(content, str):
                raise ValueError(f"Create operation for {path} needs text content.")
            op["content"] = content
            total += len(content.encode("utf-8"))
        elif action == "update":
            if path not in source_files:
                raise ValueError(f"Update target does not exist: {path}")
            old = item.get("old_content")
            new = item.get("new_content")
            if not isinstance(old, str) or not isinstance(new, str):
                raise ValueError(f"Update operation for {path} needs old_content and new_content.")
            if source_files[path] != old:
                raise ValueError(f"Update precondition mismatch for {path}")
            op["content"] = new
            total += len(old.encode("utf-8")) + len(new.encode("utf-8"))
        else:
            if path not in source_files:
                raise ValueError(f"Delete target does not exist: {path}")
            old = item.get("old_content")
            if not isinstance(old, str) or source_files[path] != old:
                raise ValueError(f"Delete precondition mismatch for {path}")
            # delete is snapshot-validated; patch_engine accepts no content.
            total += len(old.encode("utf-8"))
        if total > MAX_PLAN_BYTES:
            raise ValueError("Patch plan payload exceeds 256 KiB.")
        normalized.append(op)
    return normalized

def apply_validated_patch_plan(workspace: str, source_files: dict[str, str], plan: Any) -> list[str]:
    """Apply a fully prevalidated plan using the existing path-safe patch engine."""
    normalized = validate_patch_plan(plan, source_files)
    # Existing patch engine handles relative-path restrictions and file type limits.
    apply_patch_plan(workspace, normalized)
    return [op["path"] for op in normalized]
