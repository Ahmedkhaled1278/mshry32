"""Safe, metadata-only reconnaissance for arbitrary project ZIP uploads.

No archive member is extracted and no uploaded source code is executed.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import PurePosixPath
from stat import S_IFMT, S_IFLNK
from pathlib import Path
import zipfile

MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_ENTRIES = 2_000
MAX_TOTAL_UNCOMPRESSED = 20 * 1024 * 1024
MAX_MEMBER_BYTES = 2 * 1024 * 1024
MAX_REPORTED_FILES = 40
IGNORED_PARTS = {
    ".git", ".hg", ".svn", "node_modules", "vendor", ".venv", "venv",
    "__pycache__", "dist", "build", "target", ".next", ".nuxt",
    "coverage", ".idea", ".gradle",
}
SOURCE_EXTENSIONS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".html", ".htm",
    ".css", ".scss", ".sass", ".json", ".yaml", ".yml", ".toml", ".ini",
    ".md", ".sql", ".sh", ".bat", ".ps1", ".java", ".kt", ".kts", ".xml",
    ".gradle", ".properties", ".go", ".rs", ".php", ".rb", ".swift", ".dart",
    ".vue", ".svelte",
}
MARKERS = {
    "Python": {"pyproject.toml", "requirements.txt", "Pipfile", "setup.py"},
    "Node.js / JavaScript": {"package.json", "pnpm-lock.yaml", "yarn.lock", "package-lock.json"},
    "React / Vite": {"vite.config.js", "vite.config.ts", "next.config.js", "next.config.mjs"},
    "Flutter / Dart": {"pubspec.yaml", "analysis_options.yaml"},
    "Android / Gradle": {"settings.gradle", "settings.gradle.kts", "gradlew", "build.gradle", "build.gradle.kts"},
    "Java / Maven": {"pom.xml"},
    "Docker": {"Dockerfile", "docker-compose.yml", "compose.yaml", "compose.yml"},
    "Rust": {"Cargo.toml"},
    "Go": {"go.mod"},
}
SUSPICIOUS_NAMES = {".env", "id_rsa", "id_ed25519", "credentials.json", "service-account.json"}


@dataclass(frozen=True)
class RepositoryReport:
    total_files: int
    inspected_files: int
    ignored_files: int
    source_extensions: dict[str, int]
    detected_stacks: list[str]
    entry_candidates: list[str]
    suspicious_paths: list[str]
    files: list[str]
    warnings: list[str]

    def to_text(self) -> str:
        lines = [
            "تقرير فحص أولي للمشروع (لم يتم تشغيل أي ملف)",
            f"عدد الملفات: {self.total_files}",
            f"الملفات المصدرية المرشحة: {self.inspected_files}",
            f"الملفات المستبعدة من العرض: {self.ignored_files}",
            "التقنيات المحتملة: " + (", ".join(self.detected_stacks) or "لم يتم التعرف على إطار محدد"),
            "ملفات بداية محتملة: " + (", ".join(self.entry_candidates) or "غير معروفة"),
            "امتدادات شائعة: " + (", ".join(f"{k} ({v})" for k, v in list(self.source_extensions.items())[:12]) or "لا توجد"),
        ]
        if self.suspicious_paths:
            lines.append("أسماء ملفات حساسة محتملة (لم تُقرأ محتوياتها): " + ", ".join(self.suspicious_paths[:10]))
            lines.append("تحذير: لا ترفع أسرارًا أو مفاتيح حقيقية.")
        if self.files:
            lines.append("عينة من الملفات:")
            lines.extend(f"• {name}" for name in self.files)
        if self.warnings:
            lines.append("ملاحظات:")
            lines.extend(f"• {warning}" for warning in self.warnings)
        lines.append("هذا فحص بنية فقط، وليس تدقيقًا أمنيًا أو إثباتًا أن المشروع قابل للبناء.")
        return "\n".join(lines)


def inspect_repository_zip(path: str | Path) -> RepositoryReport:
    archive_path = Path(path)
    if not archive_path.is_file() or archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("ملف ZIP غير موجود أو يتجاوز 20 ميجابايت.")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            if not infos or len(infos) > MAX_ENTRIES:
                raise ValueError("ملف ZIP فارغ أو يحتوي على أكثر من 2000 مدخل.")
            seen: set[str] = set()
            total_uncompressed = 0
            candidates: list[str] = []
            ignored = 0
            suspicious: list[str] = []
            markers: set[str] = set()
            extensions: Counter[str] = Counter()
            warnings: list[str] = []
            total_files = 0
            for info in infos:
                name = info.filename
                if "\\" in name or "\x00" in name:
                    raise ValueError("ZIP يحتوي على اسم مسار غير آمن.")
                item = PurePosixPath(name)
                if item.is_absolute() or any(part in {"..", ""} for part in item.parts):
                    raise ValueError("ZIP يحتوي على مسار خارج مجلد المشروع.")
                if info.flag_bits & 0x1:
                    raise ValueError("ملفات ZIP المشفرة غير مدعومة.")
                mode = (info.external_attr >> 16) & 0xFFFF
                if S_IFMT(mode) == S_IFLNK:
                    raise ValueError("الروابط الرمزية غير مسموحة داخل ZIP.")
                if info.is_dir():
                    continue
                if name in seen:
                    raise ValueError("ZIP يحتوي على أسماء ملفات مكررة.")
                seen.add(name)
                total_files += 1
                total_uncompressed += info.file_size
                if total_uncompressed > MAX_TOTAL_UNCOMPRESSED:
                    raise ValueError("الحجم الإجمالي بعد فك الضغط يتجاوز 20 ميجابايت.")
                if info.file_size > MAX_MEMBER_BYTES:
                    ignored += 1
                    continue
                if any(part.lower() in IGNORED_PARTS for part in item.parts[:-1]):
                    ignored += 1
                    continue
                basename = item.name
                if basename in SUSPICIOUS_NAMES or basename.startswith(".env."):
                    suspicious.append(name)
                    ignored += 1
                    continue
                for stack, stack_markers in MARKERS.items():
                    if basename in stack_markers:
                        markers.add(stack)
                lower_name = basename.lower()
                suffix = PurePosixPath(lower_name).suffix
                if lower_name in {"dockerfile", "makefile", "procfile", "gradlew"}:
                    suffix = f"[{lower_name}]"
                known_names = {
                    "requirements.txt", "package.json", "cargo.toml", "go.mod",
                    "pom.xml", "pubspec.yaml", "pyproject.toml", "readme", "readme.md",
                    "license", ".gitignore", "makefile", "dockerfile", "gradlew",
                }
                if suffix in SOURCE_EXTENSIONS or lower_name in known_names:
                    candidates.append(name)
                    extensions[suffix or "[بدون امتداد]"] += 1
                else:
                    ignored += 1

            entry_names = {
                "index.html", "main.py", "app.py", "manage.py", "server.py",
                "main.js", "index.js", "main.ts", "main.tsx", "main.jsx", "main.dart",
                "MainActivity.kt", "main.go", "Cargo.toml", "pom.xml", "package.json", "pubspec.yaml",
            }
            entries = [name for name in candidates if PurePosixPath(name).name in entry_names]
            if len(candidates) > MAX_REPORTED_FILES:
                warnings.append(f"تم عرض أول {MAX_REPORTED_FILES} ملفًا فقط من الملفات المصدرية.")
            if not candidates:
                warnings.append("لم يتم العثور على ملفات مصدرية شائعة؛ قد يكون الأرشيف صورًا أو ملفات ثنائية.")
            if suspicious:
                warnings.append("تم تجاهل أسماء ملفات قد تحتوي على أسرار، ولم تُقرأ محتوياتها.")
            return RepositoryReport(
                total_files=total_files,
                inspected_files=len(candidates),
                ignored_files=ignored,
                source_extensions=dict(extensions.most_common()),
                detected_stacks=sorted(markers),
                entry_candidates=sorted(entries)[:20],
                suspicious_paths=sorted(suspicious)[:10],
                files=sorted(candidates)[:MAX_REPORTED_FILES],
                warnings=warnings,
            )
    except zipfile.BadZipFile as exc:
        raise ValueError("الملف المرفوع ليس ZIP صالحًا.") from exc
