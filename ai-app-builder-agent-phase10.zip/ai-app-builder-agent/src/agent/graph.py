"""LangGraph orchestration for the web MVP.

All side effects are supplied by the worker pipeline as node handlers. This keeps graph
routing testable and prevents this module from silently fabricating build results.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any, Literal, TypedDict

from langgraph.graph import END, START, StateGraph


class AgentState(TypedDict, total=False):
    job_id: str
    user_request: str
    project_type: Literal["web", "android"]
    workspace_path: str
    generated_files: dict[str, str]
    files_written: list[str]
    model: str
    token_usage: int
    build_exit_code: int
    build_log: str
    test_exit_code: int
    test_log: str
    fix_iterations: int
    fixer_exhausted: bool
    last_error: str
    security_findings: list[str]
    artifact_path: str
    artifact_sha256: str
    artifact_size_bytes: int
    verified: bool
    result_status: str
    node_history: list[str]


NodeHandler = Callable[[AgentState], dict[str, Any]]
_REQUIRED_HANDLERS = {
    "planner", "developer", "builder", "tester", "fixer",
    "security_review", "verifier", "deliverer",
}


def build_graph(handlers: Mapping[str, NodeHandler], checkpointer: Any = None):
    """Compile the real workflow; handlers must implement actual operations and checks."""
    missing = _REQUIRED_HANDLERS - set(handlers)
    if missing:
        raise ValueError(f"Missing LangGraph node handlers: {', '.join(sorted(missing))}")

    graph = StateGraph(AgentState)

    def wrap(handler: NodeHandler):
        def invoke(state: AgentState) -> dict[str, Any]:
            return handler(state)
        return invoke

    for name in sorted(_REQUIRED_HANDLERS):
        graph.add_node(name, wrap(handlers[name]))

    graph.add_edge(START, "planner")
    graph.add_edge("planner", "developer")
    graph.add_edge("developer", "builder")
    graph.add_conditional_edges(
        "builder", lambda state: "tester" if state.get("build_exit_code") == 0 else "fixer",
        {"tester": "tester", "fixer": "fixer"},
    )
    graph.add_conditional_edges(
        "tester", lambda state: "security_review" if state.get("test_exit_code") == 0 else "fixer",
        {"security_review": "security_review", "fixer": "fixer"},
    )
    graph.add_conditional_edges(
        "fixer", lambda state: END if state.get("fixer_exhausted") else "builder",
        {END: END, "builder": "builder"},
    )
    graph.add_conditional_edges(
        "security_review", lambda state: "verifier" if not state.get("security_findings") else "fixer",
        {"verifier": "verifier", "fixer": "fixer"},
    )
    graph.add_conditional_edges(
        "verifier", lambda state: "deliverer" if state.get("verified") else END,
        {"deliverer": "deliverer", END: END},
    )
    graph.add_edge("deliverer", END)
    return graph.compile(checkpointer=checkpointer)
