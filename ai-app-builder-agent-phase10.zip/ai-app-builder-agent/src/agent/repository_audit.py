"""Bounded, non-executing static audit for project ZIP uploads.

This module never extracts archive entries and never executes uploaded source.
It only reads a small allowlist of text-like files after path/size checks.
"""
from __future__ import annotations

import json
import re
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from stat import S_IFMT, S_IFLNK

from src.agent.repository_inspector import (
    IGNORED_PARTS,
    MAX_ARCHIVE_BYTES,
    MAX_ENTRIES,
    MAX_TOTAL_UNCOMPRESSED,
    SOURCE_EXTENSIONS,
    SUSPICIOUS_NAMES,
    inspect_repository_zip,
)

MAX_READ_FILES = 80
MAX_FILE_BYTES = 64 * 1024
MAX_TOTAL_READ_BYTES = 512 * 1024
MAX_FINDINGS = 80

_SECRET_PATTERNS = (
    ("مفتاح API محتمل", re.compile(r"(?i)\b(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{25,}|AKIA[0-9A-Z]{16})\b")),
    ("مفتاح خاص محتمل", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("كلمة مرور مضمنة محتملة", re.compile(r"(?i)\b(?:password|passwd|client_secret|api_key)\s*[:=]\s*['\"][^'\"]{6,}['\"]")),
)
_RISK_PATTERNS = (
    ("eval()", re.compile(r"\beval\s*\(")),
    ("Function constructor", re.compile(r"\bnew\s+Function\s*\(")),
    ("HTML insertion API", re.compile(r"\b(?:innerHTML|outerHTML)\s*=")),
    ("shell command execution API", re.compile(r"(?i)\b(?:exec|execSync|spawn|system|popen)\s*\(")),
    ("disabled TLS verification marker", re.compile(r"(?i)(?:rejectUnauthorized\s*:\s*false|verify\s*=\s*false|CERT_NONE)")),
    ("TODO/FIXME marker", re.compile(r"\b(?:TODO|FIXME|XXX)\b")),
)


@dataclass(frozen=True)
class AuditFinding:
    severity: str
    category: str
    path: str
    line: int | None
    detail: str


@dataclass(frozen=True)
class AuditReport:
    structure: object
    findings: list[AuditFinding]
    inspected_files: int
    skipped_files: int
    warnings: list[str]

    def to_text(self) -> str:
        lines = [
            "تقرير المراجعة الساكنة للمشروع",
            "==============================",
            f"عدد الملفات في الأرشيف: {self.structure.total_files}",
            f"ملفات مصدرية مرشحة: {self.structure.inspected_files}",
            f"ملفات تمت قراءة نصوصها ضمن الحدود: {self.inspected_files}",
            f"ملفات تم تجاوزها: {self.skipped_files}",
            "التقنيات المحتملة: " + (", ".join(self.structure.detected_stacks) or "غير محددة"),
            "",
            "النتائج:",
        ]
        if not self.findings:
            lines.append("لم تظهر الأنماط المحددة في الملفات التي تمت مراجعتها. هذا لا يثبت خلو المشروع من الثغرات.")
        for item in self.findings:
            location = item.path + (f":{item.line}" if item.line else "")
            lines.append(f"[{item.severity}] {item.category} — {location}: {item.detail}")
        if self.warnings:
            lines.extend(["", "حدود الفحص:"])
            lines.extend(f"- {warning}" for warning in self.warnings)
        lines.extend([
            "",
            "لم يتم تشغيل أو استخراج أي ملف من الأرشيف.",
            "هذا تقرير فرز أولي، وليس تدقيقًا أمنيًا كاملًا أو إثباتًا لصحة البناء.",
            "راجع النتائج يدويًا قبل تغيير المشروع أو نشره.",
        ])
        return "\n".join(lines)[:30_000]


def audit_repository_zip(path: str | Path) -> AuditReport:
    structure = inspect_repository_zip(path)
    findings: list[AuditFinding] = []
    warnings: list[str] = []
    inspected = 0
    skipped = 0
    total_read = 0
    try:
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            for info in infos:
                name = info.filename
                if info.is_dir():
                    continue
                item = PurePosixPath(name)
                if "\\" in name or "\x00" in name or item.is_absolute() or any(p in {"..", ""} for p in item.parts):
                    raise ValueError("ZIP يحتوي على مسار غير آمن.")
                if info.flag_bits & 0x1:
                    raise ValueError("ملفات ZIP المشفرة غير مدعومة.")
                mode = (info.external_attr >> 16) & 0xFFFF
                if S_IFMT(mode) == S_IFLNK:
                    raise ValueError("الروابط الرمزية غير مسموحة داخل ZIP.")
                if info.file_size > MAX_FILE_BYTES or total_read + info.file_size > MAX_TOTAL_READ_BYTES:
                    skipped += 1
                    continue
                if any(part.lower() in IGNORED_PARTS for part in item.parts[:-1]):
                    skipped += 1
                    continue
                base = item.name
                lower = base.lower()
                if base in SUSPICIOUS_NAMES or lower == ".env" or lower.startswith(".env."):
                    findings.append(AuditFinding("عالٍ", "ملف حساس محتمل", name, None,
                                                 "اسم الملف يشير إلى أسرار؛ احذف الأسرار من النسخة المرفوعة ودوّرها إذا كانت حقيقية."))
                    skipped += 1
                    continue
                suffix = PurePosixPath(lower).suffix
                known_text_names = {"package.json", "requirements.txt", "pyproject.toml", "cargo.toml", "go.mod", "pom.xml", "dockerfile", "makefile", "compose.yaml", "docker-compose.yml"}
                if suffix not in SOURCE_EXTENSIONS and lower not in known_text_names:
                    skipped += 1
                    continue
                if inspected >= MAX_READ_FILES:
                    skipped += 1
                    continue
                raw = archive.read(info)
                total_read += len(raw)
                try:
                    content = raw.decode("utf-8")
                except UnicodeDecodeError:
                    skipped += 1
                    continue
                inspected += 1
                for line_no, line in enumerate(content.splitlines(), start=1):
                    for label, pattern in _SECRET_PATTERNS:
                        if pattern.search(line):
                            findings.append(AuditFinding("عالٍ", "سر محتمل", name, line_no,
                                                         f"تم رصد نمط يشبه {label}؛ القيمة نفسها لم تُدرج في التقرير."))
                    for label, pattern in _RISK_PATTERNS:
                        if pattern.search(line):
                            severity = "متوسط" if label == "TODO/FIXME marker" else "يحتاج مراجعة"
                            findings.append(AuditFinding(severity, label, name, line_no,
                                                         "نمط يستحق مراجعة سياقه؛ قد يكون استخدامًا مشروعًا أو نتيجة غير دقيقة."))
                    if len(findings) >= MAX_FINDINGS:
                        warnings.append(f"توقف جمع النتائج عند الحد الأقصى ({MAX_FINDINGS}).")
                        break
                if len(findings) >= MAX_FINDINGS:
                    break
                if lower == "package.json":
                    try:
                        manifest = json.loads(content)
                        scripts = manifest.get("scripts", {}) if isinstance(manifest, dict) else {}
                        if isinstance(scripts, dict):
                            for key, value in scripts.items():
                                if isinstance(value, str) and re.search(r"(?i)(curl\s|wget\s|\|\s*(?:sh|bash)|rm\s+-rf|powershell\s+-enc)", value):
                                    findings.append(AuditFinding("عالٍ", "أمر تثبيت/تشغيل مشبوه", name, None,
                                                                 f"السكربت '{key}' يحتوي نمط shell عالي الخطورة؛ لا تشغّله قبل المراجعة."))
                    except (json.JSONDecodeError, AttributeError):
                        findings.append(AuditFinding("منخفض", "package.json غير صالح", name, None,
                                                     "تعذر تحليل ملف JSON الخاص بحزم Node.js."))
    except zipfile.BadZipFile as exc:
        raise ValueError("الملف المرفوع ليس ZIP صالحًا.") from exc

    if skipped:
        warnings.append(f"تم تجاوز {skipped} ملفًا بسبب حدود الحجم أو نوع الملف أو أسماء حساسة.")
    warnings.append("الفحص يعتمد على أنماط ساكنة محدودة؛ قد توجد نتائج كاذبة أو ثغرات لم يكتشفها.")
    return AuditReport(structure, findings[:MAX_FINDINGS], inspected, skipped, warnings)
