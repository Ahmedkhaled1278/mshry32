"""Create a deterministic, dependency-free build/test harness around generated files."""
from __future__ import annotations

import json
from pathlib import Path

from src.agent.openai_generator import ALLOWED_GENERATED_FILES

PACKAGE_JSON = {
    "name": "ai-generated-web-prototype",
    "version": "0.1.0",
    "private": True,
    "type": "module",
    "scripts": {"build": "node scripts/build.mjs", "test": "node --test tests/*.test.mjs"},
}
BUILD_SCRIPT = r'''import { access, copyFile, mkdir } from 'node:fs/promises';
import { constants } from 'node:fs';
const required = ['index.html', 'styles.css', 'app.js'];
for (const file of required) await access(file, constants.R_OK);
await mkdir('dist', { recursive: true });
for (const file of required) await copyFile(file, `dist/${file}`);
console.log(`Built ${required.length} files into dist/`);
'''
TEST_SCRIPT = r'''import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
test('HTML links local CSS and JS', async () => {
  const html = await readFile('index.html', 'utf8');
  assert.match(html, /styles\.css/);
  assert.match(html, /app\.js/);
});
test('generated assets are non-empty', async () => {
  for (const file of ['index.html', 'styles.css', 'app.js']) {
    assert.ok((await readFile(file, 'utf8')).trim().length > 0, `${file} is empty`);
  }
});
'''


def write_project(workspace: str | Path, files: dict[str, str]) -> list[str]:
    root = Path(workspace).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if set(files) != ALLOWED_GENERATED_FILES:
        raise ValueError("Unexpected generated file set")
    written: list[str] = []
    for name, content in files.items():
        if Path(name).name != name or name.startswith("."):
            raise ValueError(f"Unsafe generated path: {name}")
        target = (root / name).resolve()
        if target.parent != root:
            raise ValueError(f"Generated path escapes workspace: {name}")
        target.write_text(content, encoding="utf-8")
        written.append(name)
    (root / "package.json").write_text(json.dumps(PACKAGE_JSON, indent=2) + "\n", encoding="utf-8")
    scripts = root / "scripts"
    tests = root / "tests"
    scripts.mkdir(exist_ok=True)
    tests.mkdir(exist_ok=True)
    (scripts / "build.mjs").write_text(BUILD_SCRIPT, encoding="utf-8")
    (tests / "basic.test.mjs").write_text(TEST_SCRIPT, encoding="utf-8")
    (root / "README.md").write_text(
        "# Generated web prototype\n\nThis prototype was generated from a user request. "
        "Run `npm install --offline`, `npm run build`, and `npm test`.\n",
        encoding="utf-8",
    )
    return sorted(written + ["package.json", "scripts/build.mjs", "tests/basic.test.mjs", "README.md"])
