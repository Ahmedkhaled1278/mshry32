"""Bounded, read-only intake for multi-file project ZIPs.

This module inventories source/configuration files without extracting or executing the
uploaded archive. It is an intake primitive only: it does not imply that every detected
framework can already be built or repaired by the current pipeline.
"""
from __future__ import annotations

import zipfile
from pathlib import Path, PurePosixPath
from stat import S_IFMT, S_IFLNK
from typing import Any

MAX_ARCHIVE_BYTES = 30 * 1024 * 1024
MAX_ENTRIES = 2_000
MAX_TOTAL_UNCOMPRESSED = 12 * 1024 * 1024
MAX_FILE_BYTES = 256 * 1024
MAX_TOTAL_SOURCE_BYTES = 4 * 1024 * 1024
MAX_SOURCE_FILES = 300

# Source/configuration files useful for analysis. Dependency trees, build outputs,
# VCS metadata, secrets, binaries, and generated artifacts are deliberately excluded.
ALLOWED_SUFFIXES = {
    ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    ".html", ".htm", ".css", ".scss", ".json", ".jsonc", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".md", ".sql", ".sh", ".java", ".kt", ".kts",
    ".xml", ".gradle", ".properties", ".go", ".rs", ".php", ".rb", ".swift",
    ".dart", ".vue", ".svelte", ".txt", ".graphql", ".gql", ".prisma",
}
ALLOWED_NAMES = {
    "Dockerfile", "Makefile", "Procfile", "requirements.txt", "Pipfile",
    "Pipfile.lock", "package.json", "package-lock.json", "pnpm-lock.yaml",
    "yarn.lock", "Cargo.lock", "go.mod", "go.sum", "pom.xml", "pubspec.yaml",
    "gradlew", ".gitignore", ".dockerignore", "Gemfile", "Gemfile.lock",
    "composer.json", "composer.lock", "Justfile", "CMakeLists.txt",
}
BLOCKED_PARTS = {
    ".git", ".hg", ".svn", "node_modules", "vendor", ".venv", "venv",
    "__pycache__", "dist", "build", "target", ".next", ".nuxt", ".gradle",
    "coverage", ".idea", ".vscode", ".terraform", "Pods",
}
SECRET_NAMES = {
    ".env", ".env.local", ".env.production", ".npmrc", ".pypirc",
    "id_rsa", "id_ed25519", "credentials", "secrets.json",
}
SECRET_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".keystore", ".jks", ".sqlite", ".db"}
SECRET_PARTS = {"secrets", "secret", "credentials", "private_keys"}

def _is_candidate(path: PurePosixPath) -> bool:
    parts = {part.lower() for part in path.parts}
    name = path.name.lower()
    if parts & {p.lower() for p in BLOCKED_PARTS} or parts & SECRET_PARTS:
        return False
    if name in SECRET_NAMES or name.startswith(".env.") or name.endswith(".secret"):
        return False
    if path.suffix.lower() in SECRET_SUFFIXES:
        return False
    return path.name in ALLOWED_NAMES or path.suffix.lower() in ALLOWED_SUFFIXES

def detect_project_type(files: dict[str, str]) -> list[str]:
    """Return grounded framework hints from manifests and conventional entry points."""
    by_name: dict[str, str] = {}
    for path, content in files.items():
        by_name.setdefault(PurePosixPath(path).name, content)
    names = set(by_name)
    kinds: list[str] = []
    if "package.json" in names:
        try:
            import json
            manifest: Any = json.loads(by_name["package.json"])
            if not isinstance(manifest, dict):
                raise ValueError("package.json root is not an object")
            dependencies = manifest.get("dependencies") or {}
            dev_dependencies = manifest.get("devDependencies") or {}
            if not isinstance(dependencies, dict) or not isinstance(dev_dependencies, dict):
                raise ValueError("package dependencies must be objects")
            deps = {**dependencies, **dev_dependencies}
            if "vite" in deps:
                kinds.append("vite")
            if "next" in deps:
                kinds.append("nextjs")
            if "react" in deps:
                kinds.append("react")
            if "vue" in deps:
                kinds.append("vue")
            if "express" in deps:
                kinds.append("node-express")
            if not kinds:
                kinds.append("node")
        except (ValueError, TypeError, AttributeError):
            kinds.append("node-manifest-unparsed")
    if "pyproject.toml" in names or "requirements.txt" in names or any(n.endswith(".py") for n in files):
        kinds.append("python")
    if "pubspec.yaml" in names or any(n.endswith(".dart") for n in files):
        kinds.append("flutter-or-dart")
    if "build.gradle" in names or "build.gradle.kts" in names or any(n.endswith(".kt") for n in files):
        kinds.append("android-or-kotlin")
    if "Cargo.toml" in names or "Cargo.lock" in names:
        kinds.append("rust")
    if "go.mod" in names:
        kinds.append("go")
    if not kinds:
        kinds.append("unknown-or-static")
    return list(dict.fromkeys(kinds))

def read_project_archive(path: str | Path) -> dict[str, Any]:
    """Read bounded text files from a ZIP, without extracting or running anything.

    Returns a dict with ``files`` (safe relative path -> UTF-8 text), ``project_types``,
    and ``excluded_count``. Secret files and binary/unrecognized files are not returned.
    """
    archive_path = Path(path)
    if not archive_path.is_file() or archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("ملف ZIP غير موجود أو يتجاوز 30 ميجابايت.")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            if not infos or len(infos) > MAX_ENTRIES:
                raise ValueError("ملف ZIP فارغ أو يحتوي على عدد كبير من العناصر.")
            seen: set[str] = set()
            total_uncompressed = 0
            candidates: list[zipfile.ZipInfo] = []
            excluded = 0
            for info in infos:
                raw = info.filename
                if not raw or "\\" in raw or "\x00" in raw:
                    raise ValueError("مسار غير آمن داخل ZIP.")
                # Reject non-canonical raw paths before PurePosixPath can normalize them.
                raw_path = raw[:-1] if info.is_dir() and raw.endswith("/") else raw
                raw_parts = raw_path.split("/")
                if (raw_path.startswith("/") or not raw_path or
                        any(part in {"", ".", ".."} for part in raw_parts) or
                        raw_parts[0].endswith(":")):
                    raise ValueError("ملف ZIP يحتوي على مسار خارج مجلد المشروع أو غير موحّد.")
                rel = PurePosixPath(raw_path)
                if rel.is_absolute():
                    raise ValueError("ملف ZIP يحتوي على مسار خارج مجلد المشروع.")
                if info.flag_bits & 0x1:
                    raise ValueError("ملفات ZIP المشفرة غير مدعومة.")
                mode = (info.external_attr >> 16) & 0xFFFF
                if S_IFMT(mode) == S_IFLNK:
                    raise ValueError("الروابط الرمزية غير مسموحة داخل ZIP.")
                if info.is_dir():
                    continue
                if raw in seen:
                    raise ValueError("ملف ZIP يحتوي على أسماء مكررة.")
                seen.add(raw)
                total_uncompressed += info.file_size
                if total_uncompressed > MAX_TOTAL_UNCOMPRESSED:
                    raise ValueError("محتوى ZIP بعد فك الضغط يتجاوز 12 ميجابايت.")
                if _is_candidate(rel):
                    if info.file_size > MAX_FILE_BYTES:
                        excluded += 1
                        continue
                    candidates.append(info)
                else:
                    excluded += 1

            if len(candidates) > MAX_SOURCE_FILES:
                raise ValueError("المشروع يحتوي على ملفات مصدر كثيرة جدًا للتحليل في هذه المرحلة.")
            files: dict[str, str] = {}
            source_bytes = 0
            for info in candidates:
                source_bytes += info.file_size
                if source_bytes > MAX_TOTAL_SOURCE_BYTES:
                    raise ValueError("إجمالي ملفات المصدر يتجاوز 4 ميجابايت.")
                try:
                    content = archive.read(info).decode("utf-8")
                except UnicodeDecodeError:
                    excluded += 1
                    continue
                files[PurePosixPath(info.filename).as_posix()] = content
            if not files:
                raise ValueError("لم يتم العثور على ملفات مصدر نصية مدعومة داخل ZIP.")
            return {
                "files": files,
                "project_types": detect_project_type(files),
                "excluded_count": excluded,
                "file_count": len(files),
            }
    except zipfile.BadZipFile as exc:
        raise ValueError("الملف المرفوع ليس ZIP صالحًا.") from exc
