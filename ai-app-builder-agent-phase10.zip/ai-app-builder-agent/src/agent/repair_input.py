"""Safely read a tiny, dependency-free web prototype from an uploaded ZIP.

The archive is never extracted. Only three UTF-8 text files from one directory are
accepted; symlinks, traversal paths, duplicates, encrypted members, and oversized
archives are rejected before any source text reaches the model.
"""
from __future__ import annotations

import zipfile
from pathlib import PurePosixPath
from stat import S_IFMT, S_IFLNK
from pathlib import Path

ALLOWED_FILES = {"index.html", "styles.css", "app.js"}
MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_ENTRIES = 500
MAX_TOTAL_UNCOMPRESSED = 2 * 1024 * 1024
MAX_SOURCE_FILE_BYTES = 20 * 1024
MAX_SOURCE_CHARS_TOTAL = 18_000


def read_repair_source(path: str | Path) -> dict[str, str]:
    archive_path = Path(path)
    if not archive_path.is_file() or archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("ملف ZIP غير موجود أو يتجاوز 20 ميجابايت.")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            if not infos or len(infos) > MAX_ENTRIES:
                raise ValueError("ملف ZIP فارغ أو يحتوي على عدد كبير من الملفات.")
            total = 0
            by_path: dict[str, zipfile.ZipInfo] = {}
            for info in infos:
                raw_name = info.filename
                if "\\" in raw_name or "\x00" in raw_name:
                    raise ValueError("مسار غير آمن داخل ZIP.")
                item = PurePosixPath(raw_name)
                if item.is_absolute() or any(part in {"..", ""} for part in item.parts):
                    raise ValueError("ملف ZIP يحتوي على مسار خارج مجلد المشروع.")
                if info.flag_bits & 0x1:
                    raise ValueError("ملفات ZIP المشفرة غير مدعومة.")
                mode = (info.external_attr >> 16) & 0xFFFF
                if S_IFMT(mode) == S_IFLNK:
                    raise ValueError("الروابط الرمزية غير مسموحة داخل ZIP.")
                if info.is_dir():
                    continue
                if raw_name in by_path:
                    raise ValueError("ملف ZIP يحتوي على أسماء ملفات مكررة.")
                by_path[raw_name] = info
                total += info.file_size
                if total > MAX_TOTAL_UNCOMPRESSED:
                    raise ValueError("محتويات ZIP بعد فك الضغط تتجاوز الحد المسموح.")

            candidates: dict[str, dict[str, zipfile.ZipInfo]] = {}
            for name, info in by_path.items():
                item = PurePosixPath(name)
                if item.name in ALLOWED_FILES:
                    parent = item.parent.as_posix()
                    candidates.setdefault(parent, {})[item.name] = info
            complete = [files for files in candidates.values() if set(files) == ALLOWED_FILES]
            if len(complete) != 1:
                raise ValueError(
                    "ZIP يجب أن يحتوي في مجلد واحد على الملفات الثلاثة: "
                    "index.html وstyles.css وapp.js. هذه المرحلة تدعم نماذج الويب فقط."
                )
            source: dict[str, str] = {}
            total_chars = 0
            for name, info in complete[0].items():
                if info.file_size > MAX_SOURCE_FILE_BYTES:
                    raise ValueError(f"الملف {name} أكبر من الحد المسموح للإصلاح.")
                content = archive.read(info).decode("utf-8")
                total_chars += len(content)
                source[name] = content
            if total_chars > MAX_SOURCE_CHARS_TOTAL:
                raise ValueError("حجم الكود المرفوع أكبر من الحد المسموح لهذه المرحلة.")
            return source
    except zipfile.BadZipFile as exc:
        raise ValueError("الملف المرفوع ليس ZIP صالحًا.") from exc
    except UnicodeDecodeError as exc:
        raise ValueError("ملفات المشروع يجب أن تكون نصوص UTF-8.") from exc
