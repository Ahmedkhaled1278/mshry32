"""Conservative static review for the MVP's dependency-free generated web files."""
from __future__ import annotations

import re
from pathlib import Path

_PATTERNS = {
    "dynamic code execution via eval": re.compile(r"\beval\s*\(", re.I),
    "dynamic code execution via Function constructor": re.compile(r"\bnew\s+Function\s*\(", re.I),
    "Node child process API": re.compile(r"child_process|node:child_process", re.I),
    "embedded credential-like value": re.compile(r"(?:sk-[A-Za-z0-9_-]{20,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----)"),
    "remote script or stylesheet": re.compile(r"<(?:script|link)\b[^>]*(?:src|href)\s*=\s*['\"]https?://", re.I),
    "runtime network request": re.compile(r"\bfetch\s*\(|XMLHttpRequest|WebSocket\s*\(|sendBeacon\s*\(", re.I),
    "inline HTML event handler": re.compile(r"\bon[a-z][a-z0-9_-]*\s*=", re.I),
    "javascript URL": re.compile(r"\b(?:href|src)\s*=\s*['\"]?\s*javascript:", re.I),
}


def review_workspace(workspace: str | Path) -> list[str]:
    root = Path(workspace).resolve(strict=True)
    findings: list[str] = []
    for name in ("index.html", "styles.css", "app.js"):
        path = root / name
        if not path.is_file():
            findings.append(f"Missing required file: {name}")
            continue
        content = path.read_text(encoding="utf-8", errors="replace")
        for label, pattern in _PATTERNS.items():
            if pattern.search(content):
                findings.append(f"{name}: {label}")
    package_path = root / "package.json"
    if package_path.exists():
        import json
        package = json.loads(package_path.read_text(encoding="utf-8"))
        if package.get("dependencies") or package.get("devDependencies"):
            findings.append("MVP security policy forbids third-party npm dependencies")
    return findings
