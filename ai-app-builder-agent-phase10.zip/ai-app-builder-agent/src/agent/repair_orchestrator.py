"""Transactional orchestration for safe, multi-file ZIP repairs.

The uploaded archive is never extracted and project code is never executed here.
Only source files accepted by project_archive are sent to the planner. The resulting
archive preserves untouched original members (including assets) and replaces only
explicitly validated files. Build/test verification is a separate sandbox stage.
"""
from __future__ import annotations

import os
import tempfile
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Callable

from src.agent.multifile_patch_plan import apply_validated_patch_plan, validate_patch_plan
from src.agent.openai_patch_planner import generate_patch_plan
from src.agent.project_archive import read_project_archive

MAX_OUTPUT_ARCHIVE_BYTES = 30 * 1024 * 1024


@dataclass(frozen=True)
class RepairOutcome:
    output_path: str
    project_types: tuple[str, ...]
    source_file_count: int
    excluded_file_count: int
    created: tuple[str, ...]
    updated: tuple[str, ...]
    deleted: tuple[str, ...]
    build_verified: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _safe_zip_member(name: str) -> str:
    if not name or "\\" in name or "\x00" in name:
        raise ValueError("Unsafe ZIP member name.")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError("Unsafe ZIP member path.")
    return path.as_posix()


def repair_project_archive(
    input_zip: str | Path,
    output_zip: str | Path,
    request: str,
    *,
    api_key: str,
    model: str,
    client: Any | None = None,
    planner: Callable[..., list[dict[str, str]]] | None = None,
) -> RepairOutcome:
    """Plan, validate, apply in a temporary workspace, then atomically write output ZIP.

    ``planner`` is injectable for deterministic tests. No source archive is changed.
    The output file is replaced only after every validation and archive-write step succeeds.
    """
    source_path = Path(input_zip).resolve(strict=True)
    destination = Path(output_zip).resolve(strict=False)
    if source_path == destination:
        raise ValueError("Input and output ZIP paths must be different.")
    if not source_path.is_file() or source_path.stat().st_size > MAX_OUTPUT_ARCHIVE_BYTES:
        raise ValueError("Input ZIP is missing or exceeds the archive size limit.")
    destination.parent.mkdir(parents=True, exist_ok=True)

    inventory = read_project_archive(source_path)
    source_files: dict[str, str] = inventory["files"]
    planner_fn = planner or generate_patch_plan
    plan = planner_fn(
        request, source_files, api_key=api_key, model=model, client=client
    )
    # Preflight both snapshot preconditions and patch-engine file/path allowlists
    # before the temporary workspace is changed.
    normalized = validate_patch_plan(plan, source_files)
    # validate_patch_plan does not apply patch-engine path policy, so apply in a
    # disposable workspace and discard it on every failure.
    with tempfile.TemporaryDirectory(prefix="repair-workspace-") as temp_dir:
        workspace = Path(temp_dir).resolve()
        for relative, content in source_files.items():
            target = workspace.joinpath(*PurePosixPath(_safe_zip_member(relative)).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8", newline="")
        apply_validated_patch_plan(str(workspace), source_files, plan)

        created = tuple(op["path"] for op in normalized if op["op"] == "create")
        updated = tuple(op["path"] for op in normalized if op["op"] == "update")
        deleted = tuple(op["path"] for op in normalized if op["op"] == "delete")
        changed = set(created) | set(updated)
        deleted_set = set(deleted)

        # Build beside destination so os.replace is atomic on the same filesystem.
        fd, temp_output_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
        os.close(fd)
        temp_output = Path(temp_output_name)
        try:
            with zipfile.ZipFile(source_path, "r") as original, zipfile.ZipFile(
                temp_output, "w", allowZip64=True
            ) as result:
                seen: set[str] = set()
                for info in original.infolist():
                    name = info.filename
                    if info.is_dir():
                        # Preserve directory entries as metadata; paths were checked by intake.
                        result.writestr(info, b"")
                        continue
                    safe_name = _safe_zip_member(name)
                    if safe_name in seen:
                        raise ValueError("Duplicate ZIP member encountered while packaging output.")
                    seen.add(safe_name)
                    if safe_name in deleted_set:
                        continue
                    if safe_name in changed:
                        data = workspace.joinpath(*PurePosixPath(safe_name).parts).read_bytes()
                        result.writestr(info, data)
                    else:
                        result.writestr(info, original.read(info))
                for name in created:
                    if name in seen:
                        raise ValueError(f"Create target already exists in original ZIP: {name}")
                    target = workspace.joinpath(*PurePosixPath(name).parts)
                    result.writestr(name, target.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
            if temp_output.stat().st_size > MAX_OUTPUT_ARCHIVE_BYTES:
                raise ValueError("Repaired output ZIP exceeds the archive size limit.")
            with zipfile.ZipFile(temp_output, "r") as check:
                bad_member = check.testzip()
                if bad_member is not None:
                    raise ValueError(f"Output ZIP integrity check failed at {bad_member}.")
            os.replace(temp_output, destination)
        except Exception:
            try:
                temp_output.unlink()
            except FileNotFoundError:
                pass
            raise

    return RepairOutcome(
        output_path=str(destination),
        project_types=tuple(inventory["project_types"]),
        source_file_count=int(inventory["file_count"]),
        excluded_file_count=int(inventory["excluded_count"]),
        created=created,
        updated=updated,
        deleted=deleted,
        build_verified=False,
    )
