"""Conservative multi-file patch validation and application.

This module never executes project code. It applies an explicit JSON patch plan only
inside a caller-provided workspace, rejects path traversal/symlinks, and writes files
atomically. A sandboxed build/test stage must still verify the resulting project.
"""
from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

MAX_OPERATIONS = 100
MAX_FILE_BYTES = 512 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024
ALLOWED_SUFFIXES = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".html", ".htm",
    ".css", ".scss", ".json", ".yaml", ".yml", ".toml", ".ini", ".md",
    ".sql", ".sh", ".java", ".kt", ".kts", ".xml", ".gradle", ".properties",
    ".go", ".rs", ".php", ".rb", ".swift", ".dart", ".vue", ".svelte", ".txt",
}
ALLOWED_FILENAMES = {
    "Dockerfile", "Makefile", "Procfile", "requirements.txt", "package.json",
    "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "Cargo.lock", "go.mod",
    "go.sum", "pom.xml", "pubspec.yaml", "gradlew", ".gitignore", ".dockerignore",
}
BLOCKED_PARTS = {
    ".git", ".hg", ".svn", "node_modules", "vendor", ".venv", "venv",
    "__pycache__", "dist", "build", "target", ".next", ".nuxt", ".gradle",
}


@dataclass(frozen=True)
class PatchResult:
    created: tuple[str, ...]
    updated: tuple[str, ...]
    deleted: tuple[str, ...]
    total_bytes: int


def _safe_relative_path(raw: Any) -> PurePosixPath:
    if not isinstance(raw, str) or not raw or "\\" in raw or "\x00" in raw:
        raise ValueError("مسار الملف غير صالح.")
    # PurePosixPath normalizes repeated separators and dot components, so inspect
    # the raw spelling first to reject ambiguous aliases instead of silently folding them.
    raw_parts = raw.split("/")
    if raw.startswith("/") or any(part in {"", ".", ".."} for part in raw_parts):
        raise ValueError("المسار يحاول الخروج من مجلد المشروع أو غير موحّد.")
    if raw_parts[0].endswith(":"):
        raise ValueError("مسارات الأقراص غير مسموحة.")
    path = PurePosixPath(raw)
    if path.is_absolute():
        raise ValueError("المسار يحاول الخروج من مجلد المشروع.")
    if len(raw) > 240 or any(part.startswith(".") and part not in {".well-known"} for part in path.parts):
        raise ValueError("المسار مخفي أو أطول من الحد المسموح.")
    if any(part.lower() in BLOCKED_PARTS for part in path.parts):
        raise ValueError("تعديل مجلدات الاعتماديات أو البناء غير مسموح.")
    if path.name not in ALLOWED_FILENAMES and path.suffix.lower() not in ALLOWED_SUFFIXES:
        raise ValueError("نوع الملف غير مسموح للتعديل الآمن.")
    return path


def validate_patch_plan(plan: Any) -> list[dict[str, Any]]:
    """Validate a JSON-like plan with operations create/update/delete."""
    if not isinstance(plan, list) or not plan or len(plan) > MAX_OPERATIONS:
        raise ValueError("خطة التعديل يجب أن تحتوي من 1 إلى 100 عملية.")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    total = 0
    for item in plan:
        if not isinstance(item, dict) or set(item) - {"op", "path", "content"}:
            raise ValueError("بنية عملية التعديل غير صالحة.")
        op = item.get("op")
        if op not in {"create", "update", "delete"}:
            raise ValueError("نوع العملية غير مدعوم.")
        path = _safe_relative_path(item.get("path"))
        name = path.as_posix()
        if name in seen:
            raise ValueError("لا يمكن تعديل المسار نفسه أكثر من مرة في الخطة.")
        seen.add(name)
        if op in {"create", "update"}:
            content = item.get("content")
            if not isinstance(content, str) or "\x00" in content:
                raise ValueError("محتوى الملف يجب أن يكون نصًا صالحًا.")
            size = len(content.encode("utf-8"))
            if size > MAX_FILE_BYTES:
                raise ValueError("الملف يتجاوز 512 كيلوبايت.")
            total += size
            normalized.append({"op": op, "path": name, "content": content})
        else:
            if "content" in item:
                raise ValueError("عملية الحذف لا تقبل محتوى.")
            normalized.append({"op": op, "path": name})
    if total > MAX_TOTAL_BYTES:
        raise ValueError("إجمالي الملفات الجديدة يتجاوز 8 ميجابايت.")
    return normalized


def apply_patch_plan(workspace: str | Path, plan: Any) -> PatchResult:
    """Apply a validated plan with no symlink traversal and atomic file replacement."""
    root = Path(workspace).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("مجلد المشروع غير صالح.")
    operations = validate_patch_plan(plan)
    # Validate all paths and preconditions before mutating any file.
    resolved: list[tuple[dict[str, Any], Path, bool]] = []
    for operation in operations:
        relative = PurePosixPath(operation["path"])
        target = root.joinpath(*relative.parts)
        cursor = root
        for part in relative.parts[:-1]:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError("المسار يحتوي على رابط رمزي غير مسموح.")
        if target.is_symlink():
            raise ValueError("الهدف رابط رمزي غير مسموح.")
        try:
            target.resolve(strict=False).relative_to(root)
        except ValueError as exc:
            raise ValueError("المسار يخرج من مجلد المشروع.") from exc
        exists = target.exists()
        if operation["op"] == "create" and exists:
            raise ValueError(f"لا يمكن إنشاء ملف موجود مسبقًا: {operation['path']}")
        if operation["op"] in {"update", "delete"} and not exists:
            raise ValueError(f"الملف المطلوب تعديله غير موجود: {operation['path']}")
        if exists and not target.is_file():
            raise ValueError("يمكن تعديل الملفات العادية فقط.")
        resolved.append((operation, target, exists))

    created: list[str] = []
    updated: list[str] = []
    deleted: list[str] = []
    for operation, target, exists in resolved:
        if operation["op"] == "delete":
            target.unlink()
            deleted.append(operation["path"])
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        # Re-check ancestors after directory creation to guard against pre-existing symlinks.
        try:
            target.parent.resolve(strict=True).relative_to(root)
        except ValueError as exc:
            raise ValueError("مجلد الوجهة يخرج من مساحة المشروع.") from exc
        fd, temp_name = tempfile.mkstemp(prefix=".patch-", dir=str(target.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(operation["content"])
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, target)
        except Exception:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass
            raise
        (updated if exists else created).append(operation["path"])
    total_bytes = sum(p.stat().st_size for p in root.rglob("*") if p.is_file() and not p.is_symlink())
    return PatchResult(tuple(created), tuple(updated), tuple(deleted), total_bytes)
