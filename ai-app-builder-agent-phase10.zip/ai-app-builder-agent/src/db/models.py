from sqlalchemy import BigInteger, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": "app"}
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(Text)
    first_name: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    jobs_today: Mapped[int] = mapped_column(Integer, server_default="0", nullable=False)
    last_reset: Mapped[object] = mapped_column(Date, server_default=func.current_date(), nullable=False)


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (CheckConstraint("project_type IN ('web', 'android')", name="ck_projects_type"), {"schema": "app"})
    id: Mapped[object] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[int] = mapped_column(ForeignKey("app.users.id"), nullable=False)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    project_type: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class Job(Base):
    __tablename__ = "jobs"
    __table_args__ = (Index("idx_jobs_status", "status"), Index("idx_jobs_project", "project_id"), {"schema": "app"})
    id: Mapped[object] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    project_id: Mapped[object] = mapped_column(ForeignKey("app.projects.id"), nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False, default="queued")
    current_node: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    input_path: Mapped[str | None] = mapped_column(Text)
    token_usage: Mapped[int] = mapped_column(Integer, server_default="0", nullable=False)
    iterations: Mapped[int] = mapped_column(Integer, server_default="0", nullable=False)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    finished_at: Mapped[object | None] = mapped_column(DateTime(timezone=True))


class Event(Base):
    __tablename__ = "events"
    __table_args__ = (Index("idx_events_job_ts", "job_id", "ts"), {"schema": "app"})
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    job_id: Mapped[object] = mapped_column(ForeignKey("app.jobs.id"), nullable=False)
    ts: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    node: Mapped[str | None] = mapped_column(Text)
    event_type: Mapped[str | None] = mapped_column(Text)
    payload: Mapped[dict | None] = mapped_column(JSONB)


class Artifact(Base):
    __tablename__ = "artifacts"
    __table_args__ = {"schema": "app"}
    id: Mapped[object] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    job_id: Mapped[object] = mapped_column(ForeignKey("app.jobs.id"), nullable=False)
    kind: Mapped[str] = mapped_column(Text, nullable=False)
    s3_key: Mapped[str] = mapped_column(Text, nullable=False)
    size_bytes: Mapped[int | None] = mapped_column(BigInteger)
    sha256: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
