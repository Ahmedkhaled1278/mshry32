from datetime import date
from pathlib import Path
from uuid import UUID, uuid4

from redis import Redis
from rq.job import Job as RQJob
from sqlalchemy import delete, select
from telegram import Update
from telegram.ext import ContextTypes

from src.agent.repair_input import MAX_ARCHIVE_BYTES, read_repair_source

from src.core.config import get_settings
from src.core.state_machine import assert_transition
from src.db.models import Event, Job, Project, User
from src.db.session import get_session_factory
from src.queue.client import get_queue


def _authorized(update: Update) -> bool:
    user = update.effective_user
    return bool(user and user.id in get_settings().allowed_user_ids)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_message:
        return
    if not _authorized(update):
        await update.effective_message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    await update.effective_message.reply_text(
        "أهلًا بك في AI App Builder Agent.\n"
        "لإنشاء نموذج ويب جديد اكتب: /new ثم وصف التطبيق.\n"
        "الأوامر: /new، /inspect، /repair، /status JOB_ID، /cancel JOB_ID، /help.\n"
        "النسخة الحالية تدعم نماذج ويب JavaScript بدون اعتماديات خارجية. "
        "/inspect يفحص البنية، و/audit ينشئ تقرير مراجعة ساكنة لملفات ZIP. "
        "الإصلاح الحالي محدود بنموذج ويب صغير، وبناء APK لم يُفعّل بعد."
    )


async def new_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    user = update.effective_user
    if not message or not user:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    description = " ".join(context.args).strip()
    if len(description) < 10:
        await message.reply_text("اكتب وصفًا واضحًا لا يقل عن 10 أحرف بعد الأمر /new.")
        return
    if len(description) > 8000:
        await message.reply_text("الوصف طويل جدًا. الحد الأقصى 8000 حرف.")
        return

    settings = get_settings()
    Session = get_session_factory()
    try:
        with Session.begin() as session:
            db_user = session.execute(
                select(User).where(User.id == user.id).with_for_update()
            ).scalar_one_or_none()
            if db_user is None:
                db_user = User(id=user.id, username=user.username, first_name=user.first_name, jobs_today=0, last_reset=date.today())
                session.add(db_user)
                session.flush()
            elif db_user.last_reset != date.today():
                db_user.jobs_today = 0
                db_user.last_reset = date.today()
            if db_user.jobs_today >= settings.max_jobs_per_day:
                await message.reply_text(f"وصلت للحد اليومي الحالي ({settings.max_jobs_per_day} مهام). حاول غدًا.")
                return
            db_user.jobs_today += 1
            project = Project(user_id=user.id, name=description[:80].strip(), description=description, project_type="web")
            session.add(project)
            session.flush()
            job = Job(project_id=project.id, status="queued", current_node="queued")
            session.add(job)
            session.flush()
            job_id = str(job.id)
            session.add(Event(job_id=job.id, node="gateway", event_type="job_queued", payload={"project_type": "web"}))
        try:
            get_queue().enqueue("src.queue.worker.execute_job", job_id, job_id=job_id, result_ttl=86400, failure_ttl=604800)
        except Exception:
            # The approved state machine does not permit queued -> failed. Remove the
            # unqueued DB records in a compensating transaction so no phantom queued
            # job remains visible. The user is told that submission did not complete.
            with Session.begin() as session:
                db_job = session.get(Job, UUID(job_id))
                if db_job is not None and db_job.status == "queued":
                    project_id = db_job.project_id
                    user_id = session.execute(
                        select(Project.user_id).where(Project.id == project_id)
                    ).scalar_one_or_none()
                    session.execute(delete(Event).where(Event.job_id == db_job.id))
                    session.delete(db_job)
                    session.flush()
                    db_project = session.get(Project, project_id)
                    if db_project is not None:
                        session.delete(db_project)
                    if user_id is not None:
                        db_user = session.execute(
                            select(User).where(User.id == user_id).with_for_update()
                        ).scalar_one_or_none()
                        if db_user is not None and db_user.last_reset == date.today() and db_user.jobs_today > 0:
                            db_user.jobs_today -= 1
            await message.reply_text("تعذر وضع المهمة في قائمة التنفيذ. لم تُسجّل المهمة ولم يتم إنشاء تطبيق. حاول لاحقًا.")
            return
        await message.reply_text(f"تم تسجيل المهمة وإضافتها لقائمة الانتظار.\nJob ID: `{job_id}`\nالحالة: queued", parse_mode="Markdown")
    except Exception:
        await message.reply_text("حدث خطأ أثناء تسجيل المهمة. لم يتم إعلان أي نجاح؛ راجع سجلات الخادم.")


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message, user = update.effective_message, update.effective_user
    if not message or not user:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    if not context.args:
        await message.reply_text("الاستخدام: /status JOB_ID")
        return
    try:
        job_id = UUID(context.args[0])
    except ValueError:
        await message.reply_text("معرّف المهمة غير صالح.")
        return
    Session = get_session_factory()
    with Session() as session:
        result = session.execute(select(Job, Project).join(Project, Job.project_id == Project.id).where(Job.id == job_id, Project.user_id == user.id)).first()
        if not result:
            await message.reply_text("لم يتم العثور على المهمة.")
            return
        job, _project = result
        status, node, error = job.status, job.current_node, job.error
    text = f"Job ID: {job_id}\nالحالة: {status}\nالمرحلة: {node or 'غير محددة'}"
    if error:
        text += f"\nالتفاصيل: {error[:1000]}"
    if status == "delivered":
        text += "\nالتسليم مسجل في قاعدة البيانات؛ تحقق من سجل artifact قبل إعلان الجاهزية."
    await message.reply_text(text)


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message, user = update.effective_message, update.effective_user
    if not message or not user:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    if not context.args:
        await message.reply_text("الاستخدام: /cancel JOB_ID")
        return
    try:
        job_id = UUID(context.args[0])
    except ValueError:
        await message.reply_text("معرّف المهمة غير صالح.")
        return
    Session = get_session_factory()
    with Session.begin() as session:
        result = session.execute(select(Job).join(Project, Job.project_id == Project.id).where(Job.id == job_id, Project.user_id == user.id).with_for_update()).scalar_one_or_none()
        if result is None:
            await message.reply_text("لم يتم العثور على المهمة.")
            return
        if result.status != "queued":
            await message.reply_text(f"لا يمكن إلغاء المهمة من الحالة الحالية: {result.status}. الإلغاء مسموح حاليًا قبل بدء التنفيذ فقط.")
            return
        assert_transition(result.status, "cancelled")
        result.status = "cancelled"
        result.current_node = "cancelled"
        session.add(Event(job_id=result.id, node="gateway", event_type="job_cancelled", payload={}))
    try:
        rq_job = RQJob.fetch(str(job_id), connection=Redis.from_url(get_settings().redis_url))
        rq_job.cancel()
    except Exception:
        # DB state is authoritative for the user-facing status; worker must re-check it.
        pass
    await message.reply_text(f"تم إلغاء المهمة قبل بدء التنفيذ.\nJob ID: {job_id}")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if not message:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    await message.reply_text(
        "طريقة الاستخدام:\n"
        "/new وصف التطبيق — إنشاء نموذج ويب جديد\n"
        "/status JOB_ID — عرض الحالة\n"
        "/cancel JOB_ID — إلغاء مهمة لم تبدأ\n"
        "/inspect — أرسل ZIP مع تعليق يبدأ بـ /inspect لفحص البنية\n"
        "/audit — أرسل ZIP مع تعليق يبدأ بـ /audit لإنتاج تقرير مراجعة ساكنة\n\n"
        "النطاق الحالي: HTML/CSS/JavaScript بدون حزم خارجية. "
        "لا ترفع مفاتيح أو كلمات مرور داخل وصف التطبيق."
    )


async def repair_upload(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Accept a ZIP only when its caption explicitly starts with /repair."""
    message, user = update.effective_message, update.effective_user
    if not message or not user or not message.document:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    document = message.document
    caption = (message.caption or "").strip()
    if not caption.lower().startswith("/repair"):
        await message.reply_text("لإصلاح نموذج ويب، أرسل ZIP واكتب في التعليق: /repair ثم وصف الإصلاح المطلوب.")
        return
    if not document.file_name or not document.file_name.lower().endswith(".zip"):
        await message.reply_text("ارفع ملف ZIP فقط.")
        return
    if document.file_size is not None and document.file_size > MAX_ARCHIVE_BYTES:
        await message.reply_text("الحد الأقصى لملف ZIP هو 20 ميجابايت.")
        return
    description = caption[len("/repair"):].strip() or "افحص النموذج وحسّن الأخطاء الواضحة مع الحفاظ على التصميم والسلوك الحاليين."
    if len(description) > 4000:
        await message.reply_text("وصف الإصلاح طويل جدًا؛ الحد الأقصى 4000 حرف.")
        return

    settings = get_settings()
    Session = get_session_factory()
    input_path: Path | None = None
    try:
        incoming = Path("/workspaces/incoming").resolve()
        incoming.mkdir(parents=True, exist_ok=True)
        input_path = incoming / f"{uuid4()}.zip"
        remote_file = await context.bot.get_file(document.file_id)
        await remote_file.download_to_drive(custom_path=str(input_path))
        # Validate without extracting any archive member to the filesystem.
        read_repair_source(input_path)
        with Session.begin() as session:
            db_user = session.execute(select(User).where(User.id == user.id).with_for_update()).scalar_one_or_none()
            if db_user is None:
                db_user = User(id=user.id, username=user.username, first_name=user.first_name, jobs_today=0, last_reset=date.today())
                session.add(db_user)
                session.flush()
            elif db_user.last_reset != date.today():
                db_user.jobs_today = 0
                db_user.last_reset = date.today()
            if db_user.jobs_today >= settings.max_jobs_per_day:
                input_path.unlink(missing_ok=True)
                await message.reply_text(f"وصلت للحد اليومي الحالي ({settings.max_jobs_per_day} مهام). حاول غدًا.")
                return
            db_user.jobs_today += 1
            project = Project(user_id=user.id, name=("إصلاح: " + description[:70]).strip(),
                              description=description, project_type="web")
            session.add(project)
            session.flush()
            job = Job(project_id=project.id, status="queued", current_node="queued", input_path=str(input_path))
            session.add(job)
            session.flush()
            job_id = str(job.id)
            session.add(Event(job_id=job.id, node="gateway", event_type="repair_job_queued",
                              payload={"project_type": "web", "input_zip": True}))
        try:
            get_queue().enqueue("src.queue.worker.execute_job", job_id, job_id=job_id,
                                result_ttl=86400, failure_ttl=604800)
        except Exception:
            with Session.begin() as session:
                db_job = session.get(Job, UUID(job_id))
                if db_job is not None and db_job.status == "queued":
                    project_id = db_job.project_id
                    session.execute(delete(Event).where(Event.job_id == db_job.id))
                    session.delete(db_job)
                    session.flush()
                    db_project = session.get(Project, project_id)
                    if db_project is not None:
                        session.delete(db_project)
                    db_user = session.execute(select(User).where(User.id == user.id).with_for_update()).scalar_one_or_none()
                    if db_user and db_user.last_reset == date.today() and db_user.jobs_today > 0:
                        db_user.jobs_today -= 1
            input_path.unlink(missing_ok=True)
            await message.reply_text("تعذر وضع مهمة الإصلاح في قائمة التنفيذ؛ لم يبدأ الإصلاح.")
            return
        await message.reply_text(f"تم قبول ملف المشروع للفحص والإصلاح المحدود.\nJob ID: `{job_id}`\nاستخدم /status {job_id} لمتابعة التنفيذ.", parse_mode="Markdown")
    except ValueError as exc:
        if input_path:
            input_path.unlink(missing_ok=True)
        await message.reply_text(f"لم أقبل الملف: {str(exc)[:800]}")
    except Exception:
        if input_path:
            input_path.unlink(missing_ok=True)
        await message.reply_text("حدث خطأ أثناء استقبال ملف الإصلاح؛ لم يتم إعلان نجاح.")


async def inspect_upload(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Inspect a ZIP's project structure without executing or extracting its contents."""
    from src.agent.repository_inspector import inspect_repository_zip

    message, user = update.effective_message, update.effective_user
    if not message or not user or not message.document:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    document = message.document
    if not document.file_name or not document.file_name.lower().endswith(".zip"):
        await message.reply_text("ارفع ملف ZIP فقط لفحص بنية المشروع.")
        return
    if document.file_size is not None and document.file_size > MAX_ARCHIVE_BYTES:
        await message.reply_text("الحد الأقصى لملف ZIP هو 20 ميجابايت.")
        return
    input_path: Path | None = None
    try:
        incoming = Path("/workspaces/incoming").resolve()
        incoming.mkdir(parents=True, exist_ok=True)
        input_path = incoming / f"inspect-{uuid4()}.zip"
        remote_file = await context.bot.get_file(document.file_id)
        await remote_file.download_to_drive(custom_path=str(input_path))
        report = inspect_repository_zip(input_path)
        await message.reply_text(report.to_text()[:3900])
    except ValueError as exc:
        await message.reply_text(f"لم أقبل الملف: {str(exc)[:700]}")
    except Exception:
        await message.reply_text("تعذر فحص ملف المشروع. لم يتم تشغيل أي ملف أو إجراء تعديل عليه.")
    finally:
        if input_path:
            input_path.unlink(missing_ok=True)


async def audit_upload(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Create a downloadable, non-executing static audit report for a ZIP upload."""
    from io import BytesIO
    from src.agent.repository_audit import audit_repository_zip

    message, user = update.effective_message, update.effective_user
    if not message or not user or not message.document:
        return
    if not _authorized(update):
        await message.reply_text("غير مصرح لك باستخدام هذا البوت.")
        return
    document = message.document
    if not document.file_name or not document.file_name.lower().endswith(".zip"):
        await message.reply_text("ارفع ملف ZIP فقط لإنتاج تقرير المراجعة.")
        return
    if document.file_size is not None and document.file_size > MAX_ARCHIVE_BYTES:
        await message.reply_text("الحد الأقصى لملف ZIP هو 20 ميجابايت.")
        return

    input_path: Path | None = None
    try:
        incoming = Path("/workspaces/incoming").resolve()
        incoming.mkdir(parents=True, exist_ok=True)
        input_path = incoming / f"audit-{uuid4()}.zip"
        remote_file = await context.bot.get_file(document.file_id)
        await remote_file.download_to_drive(custom_path=str(input_path))
        report = audit_repository_zip(input_path)
        payload = BytesIO(report.to_text().encode("utf-8"))
        payload.name = "project-audit-ar.txt"
        await message.reply_document(
            document=payload,
            filename="project-audit-ar.txt",
            caption=(f"اكتمل الفحص الساكن الأولي. تمت مراجعة نصوص {report.inspected_files} ملفًا "
                     f"وتم رصد {len(report.findings)} ملاحظة. لم يتم تشغيل ملفات المشروع."),
        )
    except ValueError as exc:
        await message.reply_text(f"لم أقبل الملف: {str(exc)[:700]}")
    except Exception:
        await message.reply_text("تعذر إنشاء تقرير المراجعة. لم يتم تشغيل أي ملف أو تعديل المشروع.")
    finally:
        if input_path:
            input_path.unlink(missing_ok=True)


async def document_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Route ZIP uploads by an explicit command in the caption."""
    message = update.effective_message
    caption = (message.caption or "").strip().lower() if message else ""
    if caption.startswith("/inspect"):
        await inspect_upload(update, context)
    elif caption.startswith("/audit"):
        await audit_upload(update, context)
    else:
        await repair_upload(update, context)
