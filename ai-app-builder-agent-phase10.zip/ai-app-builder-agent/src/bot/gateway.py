import hmac
import json
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from redis import Redis
from sqlalchemy import text
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters

from src.bot.handlers import cancel_command, document_router, help_command, new_command, start_command, status_command
from src.core.config import get_settings
from src.db.session import get_engine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    telegram_app = Application.builder().token(settings.telegram_bot_token.get_secret_value()).build()
    telegram_app.add_handler(CommandHandler("start", start_command))
    telegram_app.add_handler(CommandHandler("new", new_command))
    telegram_app.add_handler(CommandHandler("status", status_command))
    telegram_app.add_handler(CommandHandler("cancel", cancel_command))
    telegram_app.add_handler(CommandHandler("help", help_command))
    telegram_app.add_handler(MessageHandler(filters.Document.ALL, document_router))
    await telegram_app.initialize()
    await telegram_app.start()
    app.state.telegram_app = telegram_app
    try:
        yield
    finally:
        await telegram_app.stop()
        await telegram_app.shutdown()


app = FastAPI(title="AI App Builder Agent", version="1.2.0-phase3-audit", lifespan=lifespan)


@app.get("/healthz")
def healthz() -> JSONResponse:
    checks = {"database": False, "redis": False}
    try:
        with get_engine().connect() as connection:
            connection.execute(text("SELECT 1"))
        checks["database"] = True
    except Exception as exc:
        logger.warning("Database health check failed: %s", type(exc).__name__)
    try:
        checks["redis"] = bool(Redis.from_url(get_settings().redis_url).ping())
    except Exception as exc:
        logger.warning("Redis health check failed: %s", type(exc).__name__)
    status_code = 200 if all(checks.values()) else 503
    return JSONResponse({"status": "ok" if status_code == 200 else "degraded", "checks": checks}, status_code=status_code)


@app.post("/webhook")
async def telegram_webhook(
    request: Request,
    x_telegram_bot_api_secret_token: str | None = Header(default=None),
):
    settings = get_settings()
    expected = settings.telegram_webhook_secret.get_secret_value()
    if not x_telegram_bot_api_secret_token or not hmac.compare_digest(x_telegram_bot_api_secret_token, expected):
        raise HTTPException(status_code=403, detail="Invalid webhook secret")
    try:
        payload = await request.json()
        update = Update.de_json(payload, request.app.state.telegram_app.bot)
        await request.app.state.telegram_app.process_update(update)
    except (json.JSONDecodeError, TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Invalid Telegram update") from None
    except Exception:
        logger.exception("Failed to process Telegram update")
        # Return 500 so Telegram may retry; handlers must be idempotent before production.
        raise HTTPException(status_code=500, detail="Update processing failed") from None
    return {"ok": True}
