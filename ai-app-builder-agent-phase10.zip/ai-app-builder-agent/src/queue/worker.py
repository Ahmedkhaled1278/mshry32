"""RQ worker entrypoint."""
from redis import Redis
from rq import Queue, Worker

from src.core.config import get_settings
from src.agent.pipeline import execute_web_job


def execute_job(job_id: str) -> dict[str, str]:
    """Stable RQ task path retained for queued jobs and backwards compatibility."""
    return execute_web_job(job_id)


def main() -> None:
    settings = get_settings()
    connection = Redis.from_url(settings.redis_url)
    worker = Worker([Queue(settings.rq_queue_name, connection=connection)],
                    connection=connection, name="ai-app-builder-worker")
    worker.work(with_scheduler=False)


if __name__ == "__main__":
    main()
