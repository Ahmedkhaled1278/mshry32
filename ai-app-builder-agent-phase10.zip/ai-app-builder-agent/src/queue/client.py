from redis import Redis
from rq import Queue
from src.core.config import get_settings


def get_queue() -> Queue:
    settings = get_settings()
    connection = Redis.from_url(settings.redis_url, decode_responses=False)
    return Queue(settings.rq_queue_name, connection=connection, default_timeout=settings.max_job_duration_seconds)
