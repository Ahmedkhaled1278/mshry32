from collections.abc import Callable
from typing import Any

ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "queued": {"planning", "cancelled"},
    "planning": {"coding", "repairing", "failed", "cancelled"},
    "repairing": {"packaging", "failed", "cancelled"},
    "packaging": {"delivering", "failed", "cancelled"},
    "coding": {"building", "failed", "cancelled"},
    "building": {"testing", "fixing", "failed", "cancelled"},
    "testing": {"security_review", "fixing", "failed", "cancelled"},
    "fixing": {"building", "testing", "failed", "cancelled"},
    "security_review": {"verifying", "fixing", "failed"},
    "verifying": {"delivering", "failed"},
    "delivering": {"delivered", "failed"},
    "delivered": set(), "failed": set(), "cancelled": set(),
}


def assert_transition(current: str, target: str) -> None:
    if current not in ALLOWED_TRANSITIONS:
        raise ValueError(f"Unknown job state: {current}")
    if target not in ALLOWED_TRANSITIONS[current]:
        raise ValueError(f"Illegal job state transition: {current} -> {target}")


def assert_can_say_done(job: Any, sha256_of: Callable[[str], str]) -> None:
    """Fail closed unless DB state and stored artifact hash prove delivery eligibility."""
    if getattr(job, "status", None) != "delivered":
        raise ValueError(f"Cannot say 'done' — job is in {getattr(job, 'status', None)}")
    artifact_key = getattr(job, "artifact_s3_key", None)
    expected_hash = getattr(job, "artifact_sha256", None)
    if not artifact_key or not expected_hash:
        raise ValueError("Cannot say 'done' — artifact key/hash is missing")
    actual_hash = sha256_of(artifact_key)
    if actual_hash != expected_hash:
        raise ValueError("Cannot say 'done' — artifact SHA-256 mismatch")
