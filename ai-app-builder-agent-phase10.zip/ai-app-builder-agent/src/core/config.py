from functools import lru_cache
from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_env: str = "development"
    log_level: str = "INFO"
    telegram_bot_token: SecretStr
    telegram_allowed_user_ids: str = Field(min_length=1)
    telegram_webhook_secret: SecretStr = Field(min_length=32)
    telegram_webhook_url: str = ""
    openai_api_key: SecretStr
    openai_model: str = "gpt-4o-mini"
    database_url: str = "postgresql+psycopg://appbuilder:change-me-local-only@localhost:5432/appbuilder"
    redis_url: str = "redis://localhost:6379/0"
    rq_queue_name: str = "default"
    max_jobs_per_day: int = Field(default=3, ge=1, le=100)
    max_job_duration_seconds: int = Field(default=1800, ge=60, le=1800)
    max_tokens_per_job: int = Field(default=200000, ge=1000, le=200000)
    max_fix_iterations: int = Field(default=5, ge=0, le=5)
    artifact_max_bytes: int = Field(default=104857600, ge=1024, le=104857600)
    s3_endpoint_url: str = "http://minio:9000"
    s3_access_key: SecretStr = SecretStr("local-minio-user")
    s3_secret_key: SecretStr = SecretStr("local-minio-password-change-me")
    s3_bucket: str = "ai-builder-artifacts"
    s3_public_base_url: str = ""

    @field_validator("telegram_bot_token", "openai_api_key")
    @classmethod
    def validate_required_secrets(cls, value: SecretStr) -> SecretStr:
        if not value.get_secret_value().strip():
            raise ValueError("Required API credentials cannot be blank")
        return value

    @field_validator("telegram_webhook_secret")
    @classmethod
    def validate_webhook_secret(cls, value: SecretStr) -> SecretStr:
        secret = value.get_secret_value().strip()
        if len(secret) < 32 or secret.startswith("replace-with-"):
            raise ValueError("TELEGRAM_WEBHOOK_SECRET must be a real random secret of at least 32 characters")
        return value

    @model_validator(mode="after")
    def validate_production_configuration(self):
        if self.app_env.lower() == "production":
            if not self.telegram_webhook_url.startswith("https://"):
                raise ValueError("Production requires an HTTPS TELEGRAM_WEBHOOK_URL")
            if "change-me-local-only" in self.database_url:
                raise ValueError("Production must not use the default local database password")
            if self.s3_access_key.get_secret_value() == "local-minio-user":
                raise ValueError("Production must configure S3_ACCESS_KEY")
            if self.s3_secret_key.get_secret_value() == "local-minio-password-change-me":
                raise ValueError("Production must configure S3_SECRET_KEY")
        return self

    @field_validator("telegram_allowed_user_ids")
    @classmethod
    def validate_user_ids(cls, value: str) -> str:
        parts = [part.strip() for part in value.split(",") if part.strip()]
        if not parts or any(not part.isdecimal() for part in parts):
            raise ValueError("TELEGRAM_ALLOWED_USER_IDS must be comma-separated numeric Telegram IDs")
        return ",".join(parts)

    @property
    def allowed_user_ids(self) -> set[int]:
        return {int(part) for part in self.telegram_allowed_user_ids.split(",")}


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
