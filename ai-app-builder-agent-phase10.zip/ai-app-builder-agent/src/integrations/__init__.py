"""External tool integrations for AI App Builder Agent."""
