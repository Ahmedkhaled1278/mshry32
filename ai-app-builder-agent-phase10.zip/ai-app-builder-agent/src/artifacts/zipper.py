from __future__ import annotations

import hashlib
import os
import zipfile
from pathlib import Path


def create_verified_zip(workspace: str | Path, output_path: str | Path, *, max_bytes: int) -> tuple[str, int]:
    root = Path(workspace).resolve(strict=True)
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(root.rglob("*")):
            # Never follow symlinks: a workspace entry could otherwise make the ZIP
            # include files outside the job's workspace (including host secrets).
            if path.is_symlink() or not path.is_file() or path.resolve() == output:
                continue
            relative = path.relative_to(root)
            if any(part in {"node_modules", ".git", "__pycache__"} for part in relative.parts):
                continue
            resolved = path.resolve(strict=True)
            if resolved != root and root not in resolved.parents:
                raise ValueError(f"Workspace file escapes root: {relative.as_posix()}")
            archive.write(path, relative.as_posix())
    size = output.stat().st_size
    if size > max_bytes:
        output.unlink(missing_ok=True)
        raise ValueError(f"Artifact exceeds configured size cap ({size} > {max_bytes})")
    digest = hashlib.sha256()
    with output.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    with zipfile.ZipFile(output, "r") as archive:
        bad = archive.testzip()
    if bad:
        output.unlink(missing_ok=True)
        raise ValueError(f"ZIP integrity check failed at {bad}")
    return digest.hexdigest(), size
