"""S3-compatible artifact storage for MinIO in development and S3/R2 in deployment."""
from __future__ import annotations

import hashlib
from pathlib import Path

import boto3
from botocore.client import Config
from botocore.exceptions import ClientError


class ArtifactStore:
    def __init__(self, *, endpoint_url: str, access_key: str, secret_key: str,
                 bucket: str, region: str = "us-east-1", public_base_url: str = "") -> None:
        self.endpoint_url = endpoint_url.rstrip("/")
        self.bucket = bucket
        self.public_base_url = public_base_url.rstrip("/")
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region
        self.client = boto3.client(
            "s3", endpoint_url=self.endpoint_url, aws_access_key_id=access_key,
            aws_secret_access_key=secret_key, region_name=region,
            config=Config(signature_version="s3v4", s3={"addressing_style": "path"},
                          retries={"max_attempts": 5, "mode": "standard"}),
        )

    def ensure_bucket(self) -> None:
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except ClientError as exc:
            code = str(exc.response.get("Error", {}).get("Code", ""))
            if code not in {"404", "NoSuchBucket", "NotFound"}:
                raise
            self.client.create_bucket(Bucket=self.bucket)

    @staticmethod
    def sha256_file(path: str | Path) -> str:
        digest = hashlib.sha256()
        with Path(path).open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def upload_verified(self, path: str | Path, key: str, expected_sha256: str) -> tuple[int, str]:
        source = Path(path)
        self.ensure_bucket()
        self.client.upload_file(str(source), self.bucket, key, ExtraArgs={"ContentType": "application/zip"})
        response = self.client.get_object(Bucket=self.bucket, Key=key)
        digest = hashlib.sha256()
        size = 0
        body = response["Body"]
        try:
            for chunk in iter(lambda: body.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
        finally:
            body.close()
        actual = digest.hexdigest()
        if actual != expected_sha256 or size != source.stat().st_size:
            raise ValueError("Uploaded artifact verification failed: remote checksum or size mismatch")
        return size, actual

    def download_url(self, key: str, expires_seconds: int = 3600) -> str:
        if not self.public_base_url:
            raise ValueError("S3_PUBLIC_BASE_URL is required for artifacts too large to send through Telegram")
        # Sign against the public reverse-proxy host itself. Rewriting a signed URL after
        # signing changes the Host header and can invalidate AWS Signature V4.
        public_client = boto3.client(
            "s3", endpoint_url=self.public_base_url,
            aws_access_key_id=self.access_key, aws_secret_access_key=self.secret_key,
            region_name=self.region,
            config=Config(signature_version="s3v4", s3={"addressing_style": "path"},
                          retries={"max_attempts": 5, "mode": "standard"}),
        )
        return public_client.generate_presigned_url(
            "get_object", Params={"Bucket": self.bucket, "Key": key}, ExpiresIn=expires_seconds
        )
