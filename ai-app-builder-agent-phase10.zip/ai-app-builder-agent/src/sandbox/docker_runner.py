"""Run a generated dependency-free Node project in a resource-limited Docker sandbox."""
from __future__ import annotations

import os
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CommandResult:
    command: str
    exit_code: int
    output: str
    duration_ms: int


class SandboxError(RuntimeError):
    pass


class DockerSandbox:
    def __init__(self, *, image: str = "node:22-alpine", timeout_seconds: int = 120,
                 max_output_chars: int = 30000, docker_bin: str = "docker") -> None:
        self.image = image
        self.timeout_seconds = timeout_seconds
        self.max_output_chars = max_output_chars
        self.docker_bin = docker_bin

    def run(self, workspace: str | Path, command: list[str]) -> CommandResult:
        root = Path(workspace).resolve(strict=True)
        if not root.is_dir():
            raise ValueError("workspace must be a directory")
        if not command or any(not isinstance(part, str) or "\x00" in part for part in command):
            raise ValueError("command must be a non-empty list of safe strings")
        container_name = "aib-job-" + uuid.uuid4().hex[:20]
        create_args = [
            self.docker_bin, "create", "--pull=missing", "--name", container_name,
            "--label", "ai-app-builder.managed=true", "--network=none",
            "--cpus=2", "--memory=2g", "--pids-limit=128", "--read-only",
            "--cap-drop=ALL", "--security-opt=no-new-privileges", "--user=1000:1000",
            "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=64m",
            "--mount", f"type=bind,src={root},dst=/workspace,rw",
            "--workdir=/workspace", self.image, *command,
        ]
        start = time.monotonic()
        container_id: str | None = None
        try:
            created = subprocess.run(
                create_args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, errors="replace",
                timeout=max(self.timeout_seconds, 180), check=False,
                env={**os.environ, "DOCKER_BUILDKIT": "1"},
            )
            if created.returncode != 0:
                return CommandResult(" ".join(command), created.returncode,
                                     created.stdout[-self.max_output_chars:],
                                     int((time.monotonic() - start) * 1000))
            container_id = created.stdout.strip().splitlines()[-1]
            completed = subprocess.run(
                [self.docker_bin, "start", "--attach", container_id],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, errors="replace", timeout=self.timeout_seconds, check=False,
                env={**os.environ, "DOCKER_BUILDKIT": "1"},
            )
            return CommandResult(" ".join(command), completed.returncode,
                                 completed.stdout[-self.max_output_chars:],
                                 int((time.monotonic() - start) * 1000))
        except subprocess.TimeoutExpired as exc:
            partial = exc.stdout or ""
            if isinstance(partial, bytes):
                partial = partial.decode("utf-8", errors="replace")
            if container_id:
                subprocess.run([self.docker_bin, "kill", container_id], stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15, check=False)
            raise SandboxError(f"Sandbox command timed out after {self.timeout_seconds}s: {partial[-4000:]}") from exc
        except FileNotFoundError as exc:
            raise SandboxError("Docker CLI is unavailable in the worker environment") from exc
        finally:
            if container_id:
                subprocess.run([self.docker_bin, "rm", "-f", container_id], stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15, check=False)

    def install(self, workspace: str | Path) -> CommandResult:
        # MVP projects are intentionally dependency-free, so offline install is enforced.
        return self.run(workspace, ["npm", "install", "--offline", "--cache=/tmp/npm-cache", "--ignore-scripts", "--no-audit", "--no-fund"])

    def build(self, workspace: str | Path) -> CommandResult:
        return self.run(workspace, ["npm", "run", "build"])

    def test(self, workspace: str | Path) -> CommandResult:
        return self.run(workspace, ["npm", "test"])
