from pathlib import Path
import zipfile

import pytest

from src.agent.repository_inspector import inspect_repository_zip


def make_zip(path: Path, files: dict[str, bytes | str]) -> Path:
    with zipfile.ZipFile(path, "w") as archive:
        for name, content in files.items():
            if isinstance(content, str):
                content = content.encode("utf-8")
            archive.writestr(name, content)
    return path


def test_inspector_detects_stacks_and_entry_points_without_extracting(tmp_path: Path):
    archive = make_zip(tmp_path / "project.zip", {
        "sample/package.json": '{"name":"sample"}',
        "sample/src/main.ts": "export {};",
        "sample/vite.config.ts": "export default {};",
        "sample/node_modules/lib/index.js": "ignored",
        "sample/.env": "SECRET=not-read",
        "sample/index.html": "<!doctype html>",
    })
    report = inspect_repository_zip(archive)
    assert "Node.js / JavaScript" in report.detected_stacks
    assert "React / Vite" in report.detected_stacks
    assert "sample/src/main.ts" in report.entry_candidates
    assert report.suspicious_paths == ["sample/.env"]
    assert not (tmp_path / "sample").exists()
    assert "لم يتم تشغيل أي ملف" in report.to_text()


def test_inspector_rejects_traversal(tmp_path: Path):
    archive = make_zip(tmp_path / "bad.zip", {"../outside.py": "print('x')"})
    with pytest.raises(ValueError, match="مسار خارج"):
        inspect_repository_zip(archive)


def test_inspector_rejects_duplicate_paths(tmp_path: Path):
    archive = tmp_path / "duplicate.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("src/main.py", "a")
        zf.writestr("src/main.py", "b")
    with pytest.raises(ValueError, match="مكررة"):
        inspect_repository_zip(archive)


def test_inspector_rejects_too_many_entries(tmp_path: Path):
    archive = tmp_path / "many.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        for i in range(2001):
            zf.writestr(f"f{i}.txt", "x")
    with pytest.raises(ValueError, match="2000"):
        inspect_repository_zip(archive)


def test_inspector_skips_dependency_and_build_directories(tmp_path: Path):
    archive = make_zip(tmp_path / "project.zip", {
        "app.py": "print('ok')",
        "node_modules/pkg/index.js": "ignored",
        "dist/bundle.js": "ignored",
        ".venv/lib/site.py": "ignored",
    })
    report = inspect_repository_zip(archive)
    assert report.files == ["app.py"]
    assert report.ignored_files == 3


def test_inspector_rejects_invalid_zip(tmp_path: Path):
    path = tmp_path / "not.zip"
    path.write_text("nope")
    with pytest.raises(ValueError, match="ليس ZIP"):
        inspect_repository_zip(path)
