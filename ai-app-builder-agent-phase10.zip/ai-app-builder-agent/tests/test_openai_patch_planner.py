import json
from types import SimpleNamespace
import pytest

from src.agent.openai_patch_planner import generate_patch_plan

class FakeClient:
    def __init__(self, content):
        self.content = content
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))
        self.calls = []
    def create(self, **kwargs):
        self.calls.append(kwargs)
        message = SimpleNamespace(content=self.content)
        return SimpleNamespace(choices=[SimpleNamespace(message=message)])

def test_openai_planner_returns_locally_validated_plan():
    source = {"src/app.py": "print('old')\n"}
    content = json.dumps({"operations": [{
        "action": "update", "path": "src/app.py",
        "old_content": "print('old')\n", "new_content": "print('new')\n"
    }]})
    client = FakeClient(content)
    plan = generate_patch_plan("Fix the output", source, api_key="test", model="fake", client=client)
    assert plan[0]["new_content"] == "print('new')\n"
    assert client.calls[0]["response_format"] == {"type": "json_object"}

def test_planner_rejects_stale_source_snapshot():
    content = json.dumps({"operations": [{
        "action": "update", "path": "src/app.py",
        "old_content": "stale", "new_content": "changed"
    }]})
    with pytest.raises(ValueError, match="precondition mismatch"):
        generate_patch_plan("Fix", {"src/app.py": "current"}, api_key="test", model="fake", client=FakeClient(content))

def test_planner_rejects_unexpected_response_keys():
    with pytest.raises(ValueError, match="operations key"):
        generate_patch_plan("Fix", {"src/app.py": "x=1"}, api_key="test", model="fake", client=FakeClient('{"operations":[],"extra":true}'))

def test_planner_rejects_empty_or_oversized_request_before_api():
    client = FakeClient('{"operations":[]}')
    with pytest.raises(ValueError, match="1–12000"):
        generate_patch_plan(" ", {"src/app.py": "x=1"}, api_key="test", model="fake", client=client)
    assert not client.calls

def test_planner_treats_empty_plan_as_failure():
    with pytest.raises(ValueError, match="could not produce"):
        generate_patch_plan("Fix", {"src/app.py": "x=1"}, api_key="test", model="fake", client=FakeClient('{"operations":[]}'))
