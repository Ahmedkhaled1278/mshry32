"""Real Docker sandbox smoke test; skipped when Docker is unavailable."""
import shutil
import subprocess
from pathlib import Path

import pytest

from src.agent.project_files import write_project
from src.sandbox.docker_runner import DockerSandbox


def _docker_ready() -> bool:
    if not shutil.which("docker"):
        return False
    try:
        return subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL, timeout=5, check=False).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


pytestmark = pytest.mark.skipif(not _docker_ready(), reason="Docker daemon is unavailable")


def test_real_sandbox_offline_install_build_and_test(tmp_path: Path):
    # Docker's node UID is 1000; the mounted workspace must be writable to that UID.
    tmp_path.chmod(0o777)
    files = {
        "index.html": '<!doctype html><html><head><link rel="stylesheet" href="styles.css"></head>'
                      '<body><main>Smoke test</main><script src="app.js"></script></body></html>',
        "styles.css": "body { font-family: sans-serif; }",
        "app.js": 'document.addEventListener("DOMContentLoaded", () => {});',
    }
    write_project(tmp_path, files)
    sandbox = DockerSandbox(timeout_seconds=180)
    try:
        install = sandbox.install(tmp_path)
        assert install.exit_code == 0, install.output
        build = sandbox.build(tmp_path)
        assert build.exit_code == 0, build.output
        tests = sandbox.test(tmp_path)
        assert tests.exit_code == 0, tests.output
        assert (tmp_path / "dist" / "index.html").is_file()
    finally:
        for path in sorted(tmp_path.rglob("*"), reverse=True):
            try:
                path.chmod(0o777 if path.is_dir() else 0o666)
            except OSError:
                pass
