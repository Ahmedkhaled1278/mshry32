from src.db.models import Artifact, Base, Event, Job, Project, User


def test_required_tables_use_app_schema():
    assert {User.__tablename__, Project.__tablename__, Job.__tablename__, Event.__tablename__, Artifact.__tablename__} == {
        "users", "projects", "jobs", "events", "artifacts"
    }
    assert {table.schema for table in Base.metadata.tables.values()} == {"app"}


def test_required_job_and_event_indexes_exist():
    job_indexes = {index.name for index in Job.__table__.indexes}
    event_indexes = {index.name for index in Event.__table__.indexes}
    assert {"idx_jobs_status", "idx_jobs_project"} <= job_indexes
    assert "idx_events_job_ts" in event_indexes


def test_project_type_is_constrained():
    constraints = {constraint.name for constraint in Project.__table__.constraints}
    assert "ck_projects_type" in constraints
