from pathlib import Path

import pytest

from src.agent.repair_patcher import apply_web_repair


def files():
    return {
        "index.html": "<!doctype html><html><head><link rel='stylesheet' href='styles.css'></head><body><script src='app.js'></script></body></html>",
        "styles.css": "body { color: black; }",
        "app.js": "console.log('old');",
    }


def test_repair_applies_only_validated_three_file_updates(tmp_path: Path):
    root = tmp_path / "workspace"
    root.mkdir()
    for name, content in files().items():
        (root / name).write_text(content, encoding="utf-8")
    updated = files()
    updated["app.js"] = "console.log('fixed');"
    result = apply_web_repair(root, updated)
    assert result.updated == ("app.js", "index.html", "styles.css")
    assert (root / "app.js").read_text(encoding="utf-8") == "console.log('fixed');"


def test_repair_rejects_missing_target_before_mutation(tmp_path: Path):
    root = tmp_path / "workspace"
    root.mkdir()
    (root / "index.html").write_text("old", encoding="utf-8")
    (root / "styles.css").write_text("old", encoding="utf-8")
    updated = files()
    with pytest.raises(ValueError, match="غير موجود"):
        apply_web_repair(root, updated)
    assert (root / "index.html").read_text(encoding="utf-8") == "old"


def test_repair_rejects_unsafe_generated_html(tmp_path: Path):
    root = tmp_path / "workspace"
    root.mkdir()
    for name, content in files().items():
        (root / name).write_text(content, encoding="utf-8")
    updated = files()
    updated["index.html"] = "<html><body></body></html>"  # missing local CSS/JS references
    with pytest.raises(ValueError):
        apply_web_repair(root, updated)
