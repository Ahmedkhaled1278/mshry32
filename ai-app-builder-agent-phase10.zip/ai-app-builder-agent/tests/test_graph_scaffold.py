import pytest

pytest.importorskip("langgraph.graph")
from src.agent.graph import build_graph  # noqa: E402


def make_handlers(*, fail_first_build=False):
    calls = {"build": 0, "fix": 0}

    def planner(state):
        return {"generated_files": {}, "fix_iterations": 0, "fixer_exhausted": False}

    def developer(state):
        return {}

    def builder(state):
        calls["build"] += 1
        code = 1 if fail_first_build and calls["build"] == 1 else 0
        return {"build_exit_code": code, "last_error": "build failed" if code else ""}

    def tester(state):
        return {"test_exit_code": 0, "last_error": ""}

    def fixer(state):
        calls["fix"] += 1
        return {"fix_iterations": state.get("fix_iterations", 0) + 1,
                "fixer_exhausted": False, "last_error": ""}

    def security(state):
        return {"security_findings": [], "last_error": ""}

    def verifier(state):
        return {"verified": True, "artifact_sha256": "test-hash"}

    def deliverer(state):
        return {"result_status": "delivered"}

    return {
        "planner": planner, "developer": developer, "builder": builder,
        "tester": tester, "fixer": fixer, "security_review": security,
        "verifier": verifier, "deliverer": deliverer,
    }, calls


def test_graph_runs_all_required_stages():
    handlers, calls = make_handlers()
    graph = build_graph(handlers)
    result = graph.invoke({"job_id": "job-1", "user_request": "make site", "fix_iterations": 0})
    assert result["result_status"] == "delivered"
    assert calls["build"] == 1
    assert calls["fix"] == 0


def test_graph_routes_build_failure_through_fixer_then_rebuild():
    handlers, calls = make_handlers(fail_first_build=True)
    graph = build_graph(handlers)
    result = graph.invoke({"job_id": "job-2", "user_request": "make site", "fix_iterations": 0})
    assert result["result_status"] == "delivered"
    assert calls["build"] == 2
    assert calls["fix"] == 1


def test_graph_rejects_missing_handlers():
    with pytest.raises(ValueError, match="Missing LangGraph node handlers"):
        build_graph({})
