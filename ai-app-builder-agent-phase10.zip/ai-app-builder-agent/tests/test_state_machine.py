from types import SimpleNamespace
import pytest

from src.core.state_machine import ALLOWED_TRANSITIONS, assert_can_say_done, assert_transition


def test_queued_can_enter_planning():
    assert_transition("queued", "planning")


def test_illegal_transition_rejected():
    with pytest.raises(ValueError, match="Illegal job state transition"):
        assert_transition("building", "delivered")


def test_terminal_states_have_no_outgoing_edges():
    for state in ("delivered", "failed", "cancelled"):
        assert ALLOWED_TRANSITIONS[state] == set()


def test_cannot_say_done_while_building():
    job = SimpleNamespace(status="building", artifact_s3_key="artifact.zip", artifact_sha256="abc")
    with pytest.raises(ValueError, match="Cannot say 'done'"):
        assert_can_say_done(job, lambda _key: "abc")


def test_cannot_say_done_without_artifact_hash():
    job = SimpleNamespace(status="delivered", artifact_s3_key="artifact.zip", artifact_sha256=None)
    with pytest.raises(ValueError, match="missing"):
        assert_can_say_done(job, lambda _key: "abc")


def test_cannot_say_done_with_hash_mismatch():
    job = SimpleNamespace(status="delivered", artifact_s3_key="artifact.zip", artifact_sha256="expected")
    with pytest.raises(ValueError, match="mismatch"):
        assert_can_say_done(job, lambda _key: "actual")


def test_done_gate_accepts_matching_hash():
    job = SimpleNamespace(status="delivered", artifact_s3_key="artifact.zip", artifact_sha256="sha256-value")
    assert_can_say_done(job, lambda _key: "sha256-value")


def test_queued_cannot_fail_without_entering_execution():
    # The approved state machine permits queued -> planning/cancelled only.
    with pytest.raises(ValueError, match="Illegal job state transition: queued -> failed"):
        assert_transition("queued", "failed")
