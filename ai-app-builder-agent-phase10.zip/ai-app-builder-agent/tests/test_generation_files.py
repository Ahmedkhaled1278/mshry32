import json
from pathlib import Path

import pytest

from src.agent.openai_generator import _validate_files
from src.agent.project_files import write_project
from src.agent.security_review import review_workspace
from src.artifacts.zipper import create_verified_zip

VALID = {
    "index.html": "<!doctype html><html><head><link rel='stylesheet' href='styles.css'></head><body><script src='app.js'></script></body></html>",
    "styles.css": "body { font-family: sans-serif; }",
    "app.js": "document.addEventListener('DOMContentLoaded', () => {});",
}


def test_generated_files_are_exact_allowlist():
    assert set(_validate_files(VALID)) == set(VALID)
    with pytest.raises(ValueError, match="exactly"):
        _validate_files({**VALID, "../../evil.sh": "echo bad"})


def test_generated_html_must_link_local_assets():
    invalid = dict(VALID)
    invalid["index.html"] = "<html><body>Hello</body></html>"
    with pytest.raises(ValueError, match="styles.css"):
        _validate_files(invalid)


def test_project_harness_is_controlled_and_dependency_free(tmp_path: Path):
    written = write_project(tmp_path / "workspace", VALID)
    root = tmp_path / "workspace"
    assert "package.json" in written
    package = json.loads((root / "package.json").read_text())
    assert package["scripts"]["build"] == "node scripts/build.mjs"
    assert "dependencies" not in package
    assert (root / "scripts/build.mjs").is_file()
    assert (root / "tests/basic.test.mjs").is_file()


def test_security_review_detects_dynamic_execution(tmp_path: Path):
    root = tmp_path / "workspace"
    write_project(root, {**VALID, "app.js": "eval('alert(1)');"})
    findings = review_workspace(root)
    assert any("eval" in finding for finding in findings)


def test_zip_is_created_and_sha256_matches(tmp_path: Path):
    root = tmp_path / "workspace"
    write_project(root, VALID)
    (root / "dist").mkdir()
    (root / "dist/index.html").write_text(VALID["index.html"])
    output = tmp_path / "artifact.zip"
    digest, size = create_verified_zip(root, output, max_bytes=1_000_000)
    import hashlib
    assert digest == hashlib.sha256(output.read_bytes()).hexdigest()
    assert size == output.stat().st_size


def test_zip_size_limit_removes_oversized_artifact(tmp_path: Path):
    root = tmp_path / "workspace"
    write_project(root, VALID)
    output = tmp_path / "artifact.zip"
    with pytest.raises(ValueError, match="exceeds configured size cap"):
        create_verified_zip(root, output, max_bytes=20)
    assert not output.exists()


def test_html_must_reference_real_local_assets_not_just_mention_names():
    invalid = dict(VALID)
    invalid["index.html"] = "<html><head><title>styles.css</title></head><body>app.js</body></html>"
    with pytest.raises(ValueError, match="link local styles.css"):
        _validate_files(invalid)


def test_html_asset_reference_order_is_not_significant():
    valid = dict(VALID)
    valid["index.html"] = "<html><head><link href='./styles.css' rel='stylesheet'></head><body><script src='./app.js'></script></body></html>"
    assert set(_validate_files(valid)) == set(valid)


def test_security_review_detects_inline_event_handlers(tmp_path: Path):
    root = tmp_path / "workspace"
    write_project(root, {**VALID, "index.html": "<html><head><link rel='stylesheet' href='styles.css'></head><body><button onclick='alert(1)'>x</button><script src='app.js'></script></body></html>"})
    findings = review_workspace(root)
    assert any("inline HTML event handler" in finding for finding in findings)


def test_security_review_detects_javascript_urls(tmp_path: Path):
    root = tmp_path / "workspace"
    write_project(root, {**VALID, "index.html": "<html><head><link rel='stylesheet' href='styles.css'></head><body><a href='javascript:alert(1)'>x</a><script src='app.js'></script></body></html>"})
    findings = review_workspace(root)
    assert any("javascript URL" in finding for finding in findings)


def test_zip_creator_never_follows_symlinks(tmp_path: Path):
    import os

    root = tmp_path / "workspace"
    write_project(root, VALID)
    secret = tmp_path / "outside-secret.txt"
    secret.write_text("must not be packaged", encoding="utf-8")
    link = root / "outside.txt"
    try:
        os.symlink(secret, link)
    except (OSError, NotImplementedError):
        pytest.skip("Symlinks unavailable in this environment")
    output = tmp_path / "artifact.zip"
    create_verified_zip(root, output, max_bytes=1_000_000)
    import zipfile
    with zipfile.ZipFile(output) as archive:
        assert "outside.txt" not in archive.namelist()
        assert all("outside-secret" not in name for name in archive.namelist())
