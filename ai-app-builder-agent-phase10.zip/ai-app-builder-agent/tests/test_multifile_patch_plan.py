from pathlib import Path
import pytest

from src.agent.multifile_patch_plan import validate_patch_plan, apply_validated_patch_plan

def test_validates_multiple_updates_and_creates():
    source = {"src/main.py": "print('old')\n"}
    plan = [
        {"action": "update", "path": "src/main.py", "old_content": "print('old')\n", "new_content": "print('new')\n"},
        {"action": "create", "path": "src/helper.py", "content": "VALUE = 1\n"},
    ]
    normalized = validate_patch_plan(plan, source)
    assert len(normalized) == 2
    assert normalized[0]["content"] == "print('new')\n"

def test_rejects_stale_precondition_before_mutation():
    with pytest.raises(ValueError, match="precondition mismatch"):
        validate_patch_plan([
            {"action": "update", "path": "src/main.py", "old_content": "stale", "new_content": "changed"}
        ], {"src/main.py": "current"})

def test_rejects_duplicate_paths():
    with pytest.raises(ValueError, match="Duplicate patch path"):
        validate_patch_plan([
            {"action": "create", "path": "a.py", "content": "x=1"},
            {"action": "create", "path": "a.py", "content": "x=2"},
        ], {})

def test_rejects_unknown_fields_shape_and_missing_targets():
    with pytest.raises(ValueError, match="unsupported action"):
        validate_patch_plan([{"action": "chmod", "path": "x.py"}], {})
    with pytest.raises(ValueError, match="does not exist"):
        validate_patch_plan([{"action": "update", "path": "missing.py", "old_content": "", "new_content": "x"}], {})

def test_apply_patch_plan_updates_real_workspace(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src/main.py").write_text("print('old')\n", encoding="utf-8")
    source = {"src/main.py": "print('old')\n"}
    plan = [{"action": "update", "path": "src/main.py", "old_content": "print('old')\n", "new_content": "print('new')\n"}]
    touched = apply_validated_patch_plan(str(tmp_path), source, plan)
    assert touched == ["src/main.py"]
    assert (tmp_path / "src/main.py").read_text(encoding="utf-8") == "print('new')\n"

@pytest.mark.parametrize("operation", [
    {"action": "create", "path": "new.py", "content": "x=1", "extra": "ignored"},
    {"action": "update", "path": "app.py", "old_content": "old", "new_content": "new", "extra": True},
])
def test_rejects_unexpected_operation_fields(operation):
    source = {"app.py": "old"}
    with pytest.raises(ValueError, match="unexpected fields"):
        validate_patch_plan([operation], source)
