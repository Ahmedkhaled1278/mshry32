from pathlib import Path

import pytest

from src.agent.patch_engine import apply_patch_plan, validate_patch_plan


def test_create_update_delete_files(tmp_path: Path):
    root = tmp_path / "workspace"
    root.mkdir()
    (root / "app.js").write_text("old", encoding="utf-8")
    result = apply_patch_plan(root, [
        {"op": "update", "path": "app.js", "content": "new"},
        {"op": "create", "path": "src/main.py", "content": "print('ok')"},
        {"op": "delete", "path": "README.md"},
    ]) if False else None
    # Delete preconditions are checked before writes, so a missing delete must abort atomically.
    with pytest.raises(ValueError, match="غير موجود"):
        apply_patch_plan(root, [
            {"op": "update", "path": "app.js", "content": "new"},
            {"op": "delete", "path": "README.md"},
        ])
    assert (root / "app.js").read_text(encoding="utf-8") == "old"
    result = apply_patch_plan(root, [
        {"op": "update", "path": "app.js", "content": "new"},
        {"op": "create", "path": "src/main.py", "content": "print('ok')"},
    ])
    assert (root / "app.js").read_text(encoding="utf-8") == "new"
    assert (root / "src/main.py").is_file()
    assert result.created == ("src/main.py",)
    assert result.updated == ("app.js",)


@pytest.mark.parametrize("path", ["../escape.py", "/tmp/escape.py", "src/../../escape.py", "node_modules/x.js", ".env"])
def test_rejects_unsafe_paths(path: str):
    with pytest.raises(ValueError):
        validate_patch_plan([{"op": "create", "path": path, "content": "x"}])


def test_rejects_duplicate_paths_and_oversized_files():
    with pytest.raises(ValueError, match="أكثر من مرة"):
        validate_patch_plan([
            {"op": "create", "path": "app.js", "content": "x"},
            {"op": "update", "path": "app.js", "content": "y"},
        ])
    with pytest.raises(ValueError, match="512 كيلوبايت"):
        validate_patch_plan([{"op": "create", "path": "app.js", "content": "x" * (512 * 1024 + 1)}])


def test_rejects_symlink_target(tmp_path: Path):
    root = tmp_path / "workspace"
    root.mkdir()
    outside = tmp_path / "outside.js"
    outside.write_text("safe", encoding="utf-8")
    (root / "app.js").symlink_to(outside)
    with pytest.raises(ValueError, match="رابط رمزي"):
        apply_patch_plan(root, [{"op": "update", "path": "app.js", "content": "bad"}])
    assert outside.read_text(encoding="utf-8") == "safe"

@pytest.mark.parametrize("bad_path", ["src//main.py", "src/./main.py", "C:/src/main.py"])
def test_rejects_noncanonical_patch_paths(tmp_path, bad_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    with pytest.raises(ValueError):
        apply_patch_plan(workspace, [{"op": "create", "path": bad_path, "content": "x"}])
