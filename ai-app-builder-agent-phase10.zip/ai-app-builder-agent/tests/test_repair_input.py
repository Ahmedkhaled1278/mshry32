from pathlib import Path
import zipfile

import pytest

from src.agent.repair_input import read_repair_source

FILES = {
    "index.html": "<html><head><link rel='stylesheet' href='styles.css'></head><body><script src='app.js'></script></body></html>",
    "styles.css": "body { color: black; }",
    "app.js": "console.log('hello');",
}


def make_zip(path: Path, files: dict[str, str], prefix: str = "site/") -> Path:
    with zipfile.ZipFile(path, "w") as archive:
        for name, content in files.items():
            archive.writestr(prefix + name, content)
    return path


def test_repair_source_reads_only_required_web_files(tmp_path: Path):
    path = make_zip(tmp_path / "site.zip", FILES)
    assert read_repair_source(path) == FILES


def test_repair_source_rejects_traversal(tmp_path: Path):
    path = tmp_path / "bad.zip"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("../index.html", FILES["index.html"])
    with pytest.raises(ValueError, match="مسار خارج"):
        read_repair_source(path)


def test_repair_source_rejects_missing_files(tmp_path: Path):
    path = make_zip(tmp_path / "incomplete.zip", {"index.html": FILES["index.html"]})
    with pytest.raises(ValueError, match="يجب أن يحتوي"):
        read_repair_source(path)


def test_repair_source_rejects_oversized_source_file(tmp_path: Path):
    oversized = dict(FILES)
    oversized["app.js"] = "x" * 21000
    path = make_zip(tmp_path / "large.zip", oversized)
    with pytest.raises(ValueError, match="أكبر من الحد"):
        read_repair_source(path)
