from pathlib import Path
from types import SimpleNamespace
import zipfile

import pytest
from src.core.state_machine import assert_transition


class FakeSession:
    def __init__(self):
        self.events = []
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def begin(self):
        return self
    def add(self, item):
        self.events.append(item)


def test_repair_job_uses_multifile_service_and_sends_verified_zip(tmp_path, monkeypatch):
    pytest.importorskip("telegram")
    from src.agent import pipeline
    source = tmp_path / "incoming.zip"
    with zipfile.ZipFile(source, "w") as archive:
        archive.writestr("src/main.py", "print('before')\n")
    monkeypatch.setenv("SANDBOX_WORKSPACE_ROOT", str(tmp_path / "work"))
    monkeypatch.setattr(pipeline, "get_settings", lambda: SimpleNamespace(
        openai_api_key=SimpleNamespace(get_secret_value=lambda: "test-key"),
        openai_model="test-model",
    ))
    statuses = []
    monkeypatch.setattr(pipeline, "_set_state", lambda job_id, target, **kw: statuses.append(target) or target)
    monkeypatch.setattr(pipeline, "_job_context", lambda job_id: ("fix it", 123, "project", "queued", str(source)))
    monkeypatch.setattr(pipeline, "_notify", lambda *args: None)
    sent = []
    monkeypatch.setattr(pipeline, "_send_document", lambda chat_id, path, caption: sent.append((chat_id, Path(path).read_bytes(), caption)))
    fake_session = FakeSession()
    monkeypatch.setattr(pipeline, "get_session_factory", lambda: lambda: fake_session)

    def fake_repair(input_zip, output_zip, request, **kwargs):
        with zipfile.ZipFile(output_zip, "w") as archive:
            archive.writestr("src/main.py", "print('after')\n")
        return SimpleNamespace(source_file_count=1, excluded_file_count=0,
                               created=(), updated=("src/main.py",), deleted=(),
                               project_types=("python",))
    monkeypatch.setattr(pipeline, "repair_project_archive", fake_repair)

    result = pipeline._execute_archive_repair_job("00000000-0000-0000-0000-000000000001", "fix it", 123, str(source))
    assert result["status"] == "delivered"
    assert result["build_verified"] == "false"
    assert [status for status in statuses if status in {"planning", "repairing", "packaging", "delivering", "delivered"}] == ["planning", "repairing", "packaging", "delivering", "delivered"]
    assert len(sent) == 1 and sent[0][0] == 123
    with zipfile.ZipFile(__import__('io').BytesIO(sent[0][1])) as delivered:
        assert delivered.read("src/main.py") == b"print('after')\n"
    assert "لم يتم تشغيل المشروع" in sent[0][2]
    assert fake_session.events[0].event_type == "repair_archive_delivered"


def test_repair_states_are_explicit_and_do_not_claim_build_verification():
    assert_transition("planning", "repairing")
    assert_transition("repairing", "packaging")
    assert_transition("packaging", "delivering")
