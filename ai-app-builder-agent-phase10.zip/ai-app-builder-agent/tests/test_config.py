import pytest
from pydantic import ValidationError
from src.core.config import Settings


def test_allowed_user_ids_parsed():
    settings = Settings(
        telegram_bot_token="test-token", telegram_allowed_user_ids="123, 456",
        telegram_webhook_secret="x" * 32, openai_api_key="test-key",
    )
    assert settings.allowed_user_ids == {123, 456}


def test_non_numeric_allowed_user_id_rejected():
    with pytest.raises(ValidationError):
        Settings(
            telegram_bot_token="test-token", telegram_allowed_user_ids="123,nope",
            telegram_webhook_secret="x" * 32, openai_api_key="test-key",
        )


def test_blank_api_credentials_are_rejected():
    with pytest.raises(ValidationError):
        Settings(
            telegram_bot_token="", telegram_allowed_user_ids="123",
            telegram_webhook_secret="x" * 32, openai_api_key="test-key",
        )


def test_default_webhook_placeholder_is_rejected():
    with pytest.raises(ValidationError):
        Settings(
            telegram_bot_token="test-token", telegram_allowed_user_ids="123",
            telegram_webhook_secret="replace-with-a-long-random-secret-value", openai_api_key="test-key",
        )


def test_production_requires_https_webhook_and_nondefault_storage_secrets():
    with pytest.raises(ValidationError, match="HTTPS TELEGRAM_WEBHOOK_URL"):
        Settings(
            app_env="production", telegram_bot_token="test-token", telegram_allowed_user_ids="123",
            telegram_webhook_secret="s" * 40, openai_api_key="test-key",
        )
