import json
from pathlib import Path

import pytest

from src.integrations.bolt_diy import prepare_bolt_handoff


def test_prepare_bolt_handoff_creates_request_and_explicit_unverified_manifest(tmp_path: Path):
    target = prepare_bolt_handoff(tmp_path / "workspace", "job_123", "Build a portfolio website")
    assert (target / "REQUEST.md").is_file()
    assert "Build a portfolio website" in (target / "REQUEST.md").read_text(encoding="utf-8")
    manifest = json.loads((target / "handoff.json").read_text(encoding="utf-8"))
    assert manifest["status"] == "prepared_not_generated"
    assert manifest["build_verified"] is False
    assert manifest["generated_files"] == []


def test_rejects_path_traversal_job_id(tmp_path: Path):
    with pytest.raises(ValueError, match="job_id"):
        prepare_bolt_handoff(tmp_path, "../escape", "Build a site")


def test_rejects_empty_request(tmp_path: Path):
    with pytest.raises(ValueError, match="empty"):
        prepare_bolt_handoff(tmp_path, "job1", "  ")


def test_rejects_duplicate_job_workspace(tmp_path: Path):
    prepare_bolt_handoff(tmp_path, "job1", "Build a site")
    with pytest.raises(FileExistsError):
        prepare_bolt_handoff(tmp_path, "job1", "Build another site")
