import subprocess
from pathlib import Path
from unittest.mock import patch

from src.sandbox.docker_runner import DockerSandbox


def test_sandbox_uses_no_network_and_resource_limits(tmp_path: Path):
    with patch("src.sandbox.docker_runner.subprocess.run") as run:
        run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout="ok")
        result = DockerSandbox().run(tmp_path, ["npm", "run", "build"])
    args = run.call_args_list[0].args[0]
    assert "--network=none" in args
    assert "--memory=2g" in args
    assert "--cpus=2" in args
    assert "--pids-limit=128" in args
    assert "--read-only" in args
    assert result.exit_code == 0


def test_sandbox_rejects_empty_command(tmp_path: Path):
    import pytest
    with pytest.raises(ValueError, match="non-empty"):
        DockerSandbox().run(tmp_path, [])


def test_timeout_kills_and_removes_container(tmp_path: Path):
    import pytest
    from src.sandbox.docker_runner import SandboxError

    created = subprocess.CompletedProcess(args=[], returncode=0, stdout="container123\n")
    timeout = subprocess.TimeoutExpired(cmd=["docker", "start"], timeout=1, output="partial")
    with patch("src.sandbox.docker_runner.subprocess.run", side_effect=[created, timeout,
             subprocess.CompletedProcess(args=[], returncode=0, stdout=""),
             subprocess.CompletedProcess(args=[], returncode=0, stdout="")]) as run:
        with pytest.raises(SandboxError, match="timed out"):
            DockerSandbox(timeout_seconds=1).run(tmp_path, ["npm", "run", "build"])
    commands = [call.args[0] for call in run.call_args_list]
    assert commands[2][:3] == ["docker", "kill", "container123"]
    assert commands[3][:3] == ["docker", "rm", "-f"]
