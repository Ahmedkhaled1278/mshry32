from pathlib import Path
import json
import zipfile
import pytest

from src.agent.project_archive import read_project_archive, detect_project_type

def write_zip(path: Path, entries: dict[str, str]) -> Path:
    with zipfile.ZipFile(path, "w") as z:
        for name, content in entries.items():
            z.writestr(name, content)
    return path

def test_reads_multifile_react_project_without_extracting(tmp_path):
    path = write_zip(tmp_path / "project.zip", {
        "myapp/package.json": json.dumps({"dependencies": {"react": "18", "vite": "5"}}),
        "myapp/src/main.jsx": "import React from 'react';",
        "myapp/src/App.jsx": "export default function App(){ return <main/> }",
        "myapp/.env": "OPENAI_API_KEY=do-not-return",
        "myapp/node_modules/pkg/index.js": "ignored",
        "myapp/dist/bundle.js": "ignored",
        "myapp/image.png": "not text",
    })
    result = read_project_archive(path)
    assert set(result["files"]) == {
        "myapp/package.json", "myapp/src/main.jsx", "myapp/src/App.jsx"
    }
    assert "vite" in result["project_types"]
    assert "react" in result["project_types"]
    assert "do-not-return" not in repr(result)
    assert result["excluded_count"] >= 4

def test_detects_flutter_hint():
    assert detect_project_type({"pubspec.yaml": "name: demo", "lib/main.dart": "void main() {}"}) == ["flutter-or-dart"]

def test_rejects_traversal(tmp_path):
    path = write_zip(tmp_path / "bad.zip", {"../src/main.py": "print(1)"})
    with pytest.raises(ValueError, match="مسار خارج"):
        read_project_archive(path)

def test_rejects_duplicate_entries(tmp_path):
    path = tmp_path / "dupe.zip"
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("src/main.py", "print(1)")
        z.writestr("src/main.py", "print(2)")
    with pytest.raises(ValueError, match="مكررة"):
        read_project_archive(path)

def test_rejects_too_many_entries(tmp_path):
    path = write_zip(tmp_path / "many.zip", {f"src/f{i}.py": "x=1" for i in range(2001)})
    with pytest.raises(ValueError, match="عدد كبير"):
        read_project_archive(path)

def test_rejects_archive_with_no_supported_text(tmp_path):
    path = write_zip(tmp_path / "empty.zip", {"project/logo.png": "binary"})
    with pytest.raises(ValueError, match="لم يتم العثور"):
        read_project_archive(path)

@pytest.mark.parametrize("member", ["src//main.py", "src/./main.py", "C:/src/main.py"])
def test_rejects_noncanonical_archive_paths(tmp_path, member):
    path = tmp_path / "bad.zip"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr(member, "print('x')")
    with pytest.raises(ValueError, match="path|مسار|ZIP|موحّد"):
        read_project_archive(path)
