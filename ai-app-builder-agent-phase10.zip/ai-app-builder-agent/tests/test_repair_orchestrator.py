import zipfile
from pathlib import Path

import pytest

from src.agent.repair_orchestrator import repair_project_archive


def make_zip(path: Path):
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("project/main.py", "print('old')\n")
        archive.writestr("project/assets/logo.bin", b"\x00\x01asset")
        archive.writestr("project/.env", "SECRET=keep-private\n")


def test_orchestrator_updates_source_and_preserves_assets_and_original(tmp_path):
    source = tmp_path / "input.zip"
    output = tmp_path / "repaired.zip"
    make_zip(source)

    def planner(request, files, **kwargs):
        assert "project/main.py" in files
        assert "project/.env" not in files
        return [{"action": "update", "path": "project/main.py",
                 "old_content": "print('old')\n", "new_content": "print('new')\n"}]

    result = repair_project_archive(source, output, "fix", api_key="test", model="fake", planner=planner)
    assert result.updated == ("project/main.py",)
    assert result.build_verified is False
    with zipfile.ZipFile(source) as original:
        assert original.read("project/main.py") == b"print('old')\n"
    with zipfile.ZipFile(output) as repaired:
        assert repaired.read("project/main.py") == b"print('new')\n"
        assert repaired.read("project/assets/logo.bin") == b"\x00\x01asset"
        assert repaired.read("project/.env") == b"SECRET=keep-private\n"
        assert repaired.testzip() is None


def test_orchestrator_failure_does_not_replace_existing_output(tmp_path):
    source = tmp_path / "input.zip"
    output = tmp_path / "repaired.zip"
    make_zip(source)
    output.write_bytes(b"previous output")

    def bad_planner(request, files, **kwargs):
        return [{"action": "update", "path": "project/main.py",
                 "old_content": "stale", "new_content": "bad"}]

    with pytest.raises(ValueError, match="precondition mismatch"):
        repair_project_archive(source, output, "fix", api_key="test", model="fake", planner=bad_planner)
    assert output.read_bytes() == b"previous output"


def test_orchestrator_rejects_same_input_and_output(tmp_path):
    source = tmp_path / "input.zip"
    make_zip(source)
    with pytest.raises(ValueError, match="different"):
        repair_project_archive(source, source, "fix", api_key="test", model="fake", planner=lambda *a, **k: [])
