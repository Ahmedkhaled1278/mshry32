# Sandboxed build policy

The worker talks to a dedicated Docker-in-Docker daemon over TLS. It mounts only the
per-job workspace into the generated-code container. The generated-code container has
`--network=none`, CPU/memory/PID limits, a read-only root filesystem, no Linux capabilities,
and a non-root UID. MVP output is deliberately dependency-free, so npm install runs offline.

The DinD service requires privileged mode. This is a development/MVP isolation boundary,
not a claim of hardened multi-tenant production isolation. For public production use, move
builds to a dedicated VM or sandbox service with a separately managed kernel boundary.
