# Optional bolt.diy browser UI. Run scripts/bootstrap_bolt_diy.sh first to
# populate vendor/bolt.diy from the official upstream stable branch.
FROM node:22-bookworm-slim
ENV PNPM_HOME="/pnpm" PATH="$PNPM_HOME:$PATH" NODE_ENV=development
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends ca-certificates \
    && rm -rf /var/lib/apt/lists/* \
    && corepack enable && corepack prepare pnpm@9.15.9 --activate
COPY vendor/bolt.diy/ /app/
RUN pnpm install --frozen-lockfile
EXPOSE 5173
CMD ["pnpm", "run", "dev", "--host", "0.0.0.0"]
