#!/usr/bin/env sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
DEST="$ROOT_DIR/vendor/bolt.diy"
REPO="https://github.com/stackblitz-labs/bolt.diy.git"
BRANCH="stable"

if [ -e "$DEST/.git" ]; then
  echo "bolt.diy checkout already exists at $DEST"
  echo "Review local changes before updating it; this script will not overwrite them."
  exit 0
fi
if [ -e "$DEST" ]; then
  echo "Refusing to overwrite non-git path: $DEST" >&2
  exit 1
fi
mkdir -p "$(dirname "$DEST")"
git clone --depth 1 --branch "$BRANCH" "$REPO" "$DEST"
printf '\nbolt.diy source checked out at: %s\n' "$DEST"
printf 'Next: set OPENAI_API_KEY in .env and run: docker compose --profile bolt-ui up --build bolt-diy\n'
printf 'Note: this starts the optional browser UI; it does not expose a headless generation API.\n'
