"""Register the configured HTTPS webhook with Telegram without printing secrets."""
from __future__ import annotations

import json
import os
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def main() -> int:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    webhook_url = os.getenv("TELEGRAM_WEBHOOK_URL", "").strip()
    secret = os.getenv("TELEGRAM_WEBHOOK_SECRET", "").strip()
    if not token or not webhook_url.startswith("https://") or len(secret) < 32:
        print("Set TELEGRAM_BOT_TOKEN, an HTTPS TELEGRAM_WEBHOOK_URL, and a 32+ character TELEGRAM_WEBHOOK_SECRET.", file=sys.stderr)
        return 2
    endpoint = f"https://api.telegram.org/bot{token}/setWebhook"
    payload = json.dumps({"url": webhook_url, "secret_token": secret, "drop_pending_updates": False}).encode()
    request = Request(endpoint, data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(request, timeout=20) as response:
            result = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, ValueError) as exc:
        print(f"Webhook registration failed ({type(exc).__name__}); token was not printed.", file=sys.stderr)
        return 1
    if result.get("ok") is not True:
        print("Telegram rejected the webhook request. Check URL and bot configuration.", file=sys.stderr)
        return 1
    print("Telegram webhook registered successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
