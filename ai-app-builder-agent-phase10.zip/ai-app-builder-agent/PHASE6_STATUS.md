# Phase 6 — Multi-file project archive intake

## Implemented
- Added `src/agent/project_archive.py`, a read-only ZIP intake layer for bounded multi-file projects.
- The reader never extracts or executes uploaded content. It rejects traversal, duplicate names, symlinks, encrypted entries, oversized archives, and excessive file counts.
- It reads a conservative allowlist of UTF-8 source/configuration files and excludes common dependency/build folders, environment files, credential names, private-key formats, and binary/unrecognized files.
- It reports conservative framework hints for Vite/React/Next.js/Vue/Node, Python, Flutter/Dart, Android/Kotlin, Rust, and Go.
- Added tests for multi-file React intake, Flutter hints, traversal, duplicates, excessive entries, and empty supported-source archives.

## Validation
This phase is an intake foundation, not general AI repair. The current AI generation/repair pipeline still writes and validates only `index.html`, `styles.css`, and `app.js`; it does not yet apply arbitrary multi-file patches or run framework-specific builds. Framework detection is heuristic and not a security verdict.
