# Phase 5 — Wire the patch engine into web repair

## Implemented
- Added `src/agent/repair_patcher.py`, a small adapter that validates AI-generated files using the existing generated-file validator and applies the three-file repair through the Phase 4 bounded patch engine.
- Connected the repair-mode developer node and subsequent AI fixer iterations to the patch adapter.
- Seeds a fresh repair workspace with the uploaded prototype before applying updates, while avoiding a reset when the three source files are already present on worker retries.
- Added tests for normal patching, missing target preconditions, and invalid generated HTML structure.

## Scope boundary
- `/repair` still supports only a ZIP containing `index.html`, `styles.css`, and `app.js` in one directory.
- This phase does not claim arbitrary repository repair, native Android/Gradle builds, or APK output.
- The generated output still must pass the existing Docker build, test, security review, artifact verification, and delivery workflow in a configured deployment.

## Verification
Run `python -m compileall -q src tests` and `python -m pytest -q`.
Docker-backed build and live Telegram/OpenAI/Postgres/Redis/MinIO integration require a configured environment.
