# Phase 1 acceptance record

## Scope accepted for v1.0

- Telegram-triggered generation of dependency-free JavaScript web prototypes.
- Limited repair for ZIPs that contain `index.html`, `styles.css`, and `app.js` in one directory; this is not arbitrary repository repair.
- OpenAI API as the generation provider.
- Docker Compose development stack with PostgreSQL, Redis/RQ, MinIO, gateway, worker, and an isolated build sandbox.
- Build/test/security gates before artifact delivery.
- Optional bolt.diy browser UI only; no undocumented headless API is assumed.

Android APK generation, hosting generated apps, iOS, multi-tenant UI, and full continuation/repair of arbitrary existing repositories are not Phase 1 deliverables.

## Checks run for this package

- `python -m compileall -q src tests`: passed.
- `python -m pytest -q`: **38 passed, 2 skipped** in the available environment.
  - LangGraph graph tests were skipped because `langgraph` is not installed in the inspection environment.
  - Real Docker sandbox integration was skipped because Docker is unavailable in the inspection environment.
- Generated-project smoke fixture: `npm install --offline`, `npm run build`, and `npm test` passed; Node reported 2/2 tests passed.
- Docker Compose YAML parsed and required services were present.
- Added validation that HTML must actually reference the allowed local CSS/JS assets, plus static checks for inline HTML event handlers and `javascript:` URLs.
- Added archive repair-input safety tests, ZIP symlink omission test, and validation for missing/placeholder API credentials.
- Added Telegram webhook registration helper; it requires a configured HTTPS URL and does not print the bot token.

## Not yet accepted / must be tested in a configured environment

- Full CI job with all development dependencies installed.
- Docker image builds and real Docker-in-Docker sandbox run.
- Live OpenAI API generation and token-limit behavior.
- Live Telegram webhook authentication, commands, delivery, and failure behavior.
- PostgreSQL migrations/checkpoint schema and worker kill/restart recovery.
- Redis/RQ execution and cancellation races.
- MinIO upload/download checksum verification and large-artifact public link delivery.
- End-to-end test from `/new` to a received, verified ZIP.

## Acceptance decision

**Implementation package for Phase 1 review: ready for configured integration testing, not certified complete or production-ready.** Do not report end-to-end success until the remaining checks above have passed on a real configured stack.
