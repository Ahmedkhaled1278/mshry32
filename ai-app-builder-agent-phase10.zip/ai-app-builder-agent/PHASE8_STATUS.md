# Phase 8 — OpenAI patch planning

## Implemented
- Added `src/agent/openai_patch_planner.py`.
- Sends a bounded source snapshot and repair request to OpenAI using JSON mode.
- Requires a strict `operations` response and validates create/update/delete plans locally against the exact source snapshot before returning them.
- Rejects malformed responses, stale old-content preconditions, empty plans, oversized prompts/snapshots, and unexpected response fields.
- Added tests with a fake OpenAI-compatible client; these test validation behavior without using paid API calls.

## Explicit limits
- This planner is not yet wired into Telegram or the production job pipeline.
- No real OpenAI API call was made during tests.
- It does not apply the returned plan, run project-specific tests/builds, produce an APK, or certify that a repair works.
- Never treat a model-generated plan as trusted; the next integration stage must apply it only in a disposable workspace, snapshot/rollback on failure, and verify changes before delivery.
